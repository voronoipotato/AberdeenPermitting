﻿namespace BuildingPermit
{
    partial class ConditionalUseApp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ConditionalUseApp));
            this.label10 = new System.Windows.Forms.Label();
            this.TextBox9 = new System.Windows.Forms.TextBox();
            this.Label9 = new System.Windows.Forms.Label();
            this.TextBox8 = new System.Windows.Forms.TextBox();
            this.Label8 = new System.Windows.Forms.Label();
            this.TextBox7 = new System.Windows.Forms.TextBox();
            this.Label7 = new System.Windows.Forms.Label();
            this.TextBox6 = new System.Windows.Forms.TextBox();
            this.Label6 = new System.Windows.Forms.Label();
            this.TextBox5 = new System.Windows.Forms.TextBox();
            this.Label5 = new System.Windows.Forms.Label();
            this.TextBox4 = new System.Windows.Forms.TextBox();
            this.Label4 = new System.Windows.Forms.Label();
            this.TextBox3 = new System.Windows.Forms.TextBox();
            this.Label3 = new System.Windows.Forms.Label();
            this.TextBox2 = new System.Windows.Forms.TextBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.TextBox1 = new System.Windows.Forms.TextBox();
            this.Label1 = new System.Windows.Forms.Label();
            this.Title = new System.Windows.Forms.Label();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(14, 233);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(595, 13);
            this.label10.TabIndex = 53;
            this.label10.Text = "---------------------------------------------------------------------------------" +
                "--------------------------------------------------------------------------------" +
                "-----------------------------------";
            // 
            // TextBox9
            // 
            this.TextBox9.Location = new System.Drawing.Point(60, 200);
            this.TextBox9.Name = "TextBox9";
            this.TextBox9.Size = new System.Drawing.Size(502, 20);
            this.TextBox9.TabIndex = 44;
            // 
            // Label9
            // 
            this.Label9.AutoSize = true;
            this.Label9.Location = new System.Drawing.Point(14, 200);
            this.Label9.Name = "Label9";
            this.Label9.Size = new System.Drawing.Size(45, 13);
            this.Label9.TabIndex = 39;
            this.Label9.Text = "Address";
            // 
            // TextBox8
            // 
            this.TextBox8.Location = new System.Drawing.Point(254, 158);
            this.TextBox8.Name = "TextBox8";
            this.TextBox8.Size = new System.Drawing.Size(100, 20);
            this.TextBox8.TabIndex = 42;
            // 
            // Label8
            // 
            this.Label8.AutoSize = true;
            this.Label8.Location = new System.Drawing.Point(194, 161);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(54, 13);
            this.Label8.TabIndex = 38;
            this.Label8.Text = "Cellphone";
            // 
            // TextBox7
            // 
            this.TextBox7.Location = new System.Drawing.Point(60, 161);
            this.TextBox7.Name = "TextBox7";
            this.TextBox7.Size = new System.Drawing.Size(100, 20);
            this.TextBox7.TabIndex = 43;
            // 
            // Label7
            // 
            this.Label7.AutoSize = true;
            this.Label7.Location = new System.Drawing.Point(14, 161);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(32, 13);
            this.Label7.TabIndex = 36;
            this.Label7.Text = "Email";
            // 
            // TextBox6
            // 
            this.TextBox6.Location = new System.Drawing.Point(503, 116);
            this.TextBox6.Name = "TextBox6";
            this.TextBox6.Size = new System.Drawing.Size(59, 20);
            this.TextBox6.TabIndex = 50;
            // 
            // Label6
            // 
            this.Label6.AutoSize = true;
            this.Label6.Location = new System.Drawing.Point(475, 119);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(22, 13);
            this.Label6.TabIndex = 40;
            this.Label6.Text = "Zip";
            // 
            // TextBox5
            // 
            this.TextBox5.Location = new System.Drawing.Point(414, 115);
            this.TextBox5.Name = "TextBox5";
            this.TextBox5.Size = new System.Drawing.Size(43, 20);
            this.TextBox5.TabIndex = 52;
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Location = new System.Drawing.Point(376, 119);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(32, 13);
            this.Label5.TabIndex = 37;
            this.Label5.Text = "State";
            // 
            // TextBox4
            // 
            this.TextBox4.Location = new System.Drawing.Point(248, 115);
            this.TextBox4.Name = "TextBox4";
            this.TextBox4.Size = new System.Drawing.Size(100, 20);
            this.TextBox4.TabIndex = 45;
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Location = new System.Drawing.Point(218, 118);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(24, 13);
            this.Label4.TabIndex = 41;
            this.Label4.Text = "City";
            // 
            // TextBox3
            // 
            this.TextBox3.Location = new System.Drawing.Point(101, 118);
            this.TextBox3.Name = "TextBox3";
            this.TextBox3.Size = new System.Drawing.Size(100, 20);
            this.TextBox3.TabIndex = 51;
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Location = new System.Drawing.Point(14, 118);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(81, 13);
            this.Label3.TabIndex = 33;
            this.Label3.Text = "Mailing Address";
            // 
            // TextBox2
            // 
            this.TextBox2.Location = new System.Drawing.Point(397, 80);
            this.TextBox2.Name = "TextBox2";
            this.TextBox2.Size = new System.Drawing.Size(100, 20);
            this.TextBox2.TabIndex = 49;
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Location = new System.Drawing.Point(343, 83);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(48, 13);
            this.Label2.TabIndex = 34;
            this.Label2.Text = "Phone #";
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(172, 80);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(37, 20);
            this.textBox11.TabIndex = 47;
            this.textBox11.Text = "MI";
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(215, 80);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(89, 20);
            this.textBox10.TabIndex = 46;
            this.textBox10.Text = "Last Name";
            // 
            // TextBox1
            // 
            this.TextBox1.Location = new System.Drawing.Point(71, 80);
            this.TextBox1.Name = "TextBox1";
            this.TextBox1.Size = new System.Drawing.Size(89, 20);
            this.TextBox1.TabIndex = 48;
            this.TextBox1.Text = "First Name";
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Location = new System.Drawing.Point(14, 83);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(51, 13);
            this.Label1.TabIndex = 35;
            this.Label1.Text = "Applicant";
            // 
            // Title
            // 
            this.Title.AutoSize = true;
            this.Title.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Title.Location = new System.Drawing.Point(12, 9);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(279, 26);
            this.Title.TabIndex = 54;
            this.Title.Text = "Conditional Use Application";
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(103, 268);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(460, 20);
            this.textBox12.TabIndex = 56;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(15, 268);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(82, 13);
            this.label11.TabIndex = 55;
            this.label11.Text = "Existing Zoning:";
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(172, 304);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(391, 20);
            this.textBox13.TabIndex = 58;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(15, 304);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(154, 13);
            this.label12.TabIndex = 57;
            this.label12.Text = "Existing Land Use On Property:";
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(131, 339);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(431, 20);
            this.textBox14.TabIndex = 60;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(14, 339);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(111, 13);
            this.label13.TabIndex = 59;
            this.label13.Text = "Requested Land Use:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(12, 373);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(595, 13);
            this.label14.TabIndex = 61;
            this.label14.Text = "---------------------------------------------------------------------------------" +
                "--------------------------------------------------------------------------------" +
                "-----------------------------------";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(12, 395);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(213, 24);
            this.label15.TabIndex = 62;
            this.label15.Text = "Statement of Justification";
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(12, 478);
            this.textBox15.Multiline = true;
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(550, 68);
            this.textBox15.TabIndex = 64;
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(18, 614);
            this.textBox16.Multiline = true;
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(550, 68);
            this.textBox16.TabIndex = 67;
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(18, 765);
            this.textBox17.Multiline = true;
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(550, 68);
            this.textBox17.TabIndex = 70;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(491, 840);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 73;
            this.button1.Text = "Ne&xt";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // label16
            // 
            this.label16.Location = new System.Drawing.Point(12, 431);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(600, 30);
            this.label16.TabIndex = 88;
            this.label16.Text = "C. The A. The establishment, maintenance or operation of the conditional use will" +
                " not be detrimental to or endanger the public health, safety, morals, comfort or" +
                " general welfare:";
            // 
            // label17
            // 
            this.label17.Location = new System.Drawing.Point(13, 561);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(600, 30);
            this.label17.TabIndex = 89;
            this.label17.Text = resources.GetString("label17.Text");
            // 
            // label18
            // 
            this.label18.Location = new System.Drawing.Point(12, 715);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(600, 30);
            this.label18.TabIndex = 90;
            this.label18.Text = resources.GetString("label18.Text");
            // 
            // ConditionalUseApp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(664, 882);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox17);
            this.Controls.Add(this.textBox16);
            this.Controls.Add(this.textBox15);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.textBox14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.textBox13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.textBox12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.Title);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.TextBox9);
            this.Controls.Add(this.Label9);
            this.Controls.Add(this.TextBox8);
            this.Controls.Add(this.Label8);
            this.Controls.Add(this.TextBox7);
            this.Controls.Add(this.Label7);
            this.Controls.Add(this.TextBox6);
            this.Controls.Add(this.Label6);
            this.Controls.Add(this.TextBox5);
            this.Controls.Add(this.Label5);
            this.Controls.Add(this.TextBox4);
            this.Controls.Add(this.Label4);
            this.Controls.Add(this.TextBox3);
            this.Controls.Add(this.Label3);
            this.Controls.Add(this.TextBox2);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.textBox11);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.TextBox1);
            this.Controls.Add(this.Label1);
            this.Name = "ConditionalUseApp";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label10;
        internal System.Windows.Forms.TextBox TextBox9;
        internal System.Windows.Forms.Label Label9;
        internal System.Windows.Forms.TextBox TextBox8;
        internal System.Windows.Forms.Label Label8;
        internal System.Windows.Forms.TextBox TextBox7;
        internal System.Windows.Forms.Label Label7;
        internal System.Windows.Forms.TextBox TextBox6;
        internal System.Windows.Forms.Label Label6;
        internal System.Windows.Forms.TextBox TextBox5;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.TextBox TextBox4;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.TextBox TextBox3;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.TextBox TextBox2;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.TextBox textBox11;
        internal System.Windows.Forms.TextBox textBox10;
        internal System.Windows.Forms.TextBox TextBox1;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.Label Title;
        internal System.Windows.Forms.TextBox textBox12;
        internal System.Windows.Forms.Label label11;
        internal System.Windows.Forms.TextBox textBox13;
        internal System.Windows.Forms.Label label12;
        internal System.Windows.Forms.TextBox textBox14;
        internal System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        internal System.Windows.Forms.Label label15;
        internal System.Windows.Forms.TextBox textBox15;
        internal System.Windows.Forms.TextBox textBox16;
        internal System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.Button button1;
        internal System.Windows.Forms.Label label16;
        internal System.Windows.Forms.Label label17;
        internal System.Windows.Forms.Label label18;
    }
}