﻿namespace BuildingPermit
{
    partial class BuildingPermitTabs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.label24 = new System.Windows.Forms.Label();
            this.dateTimePicker3 = new System.Windows.Forms.DateTimePicker();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label21 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.btnFees = new System.Windows.Forms.Button();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.maskedTextBox10 = new System.Windows.Forms.MaskedTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.maskedTextBox11 = new System.Windows.Forms.MaskedTextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.btnOwnerContact = new System.Windows.Forms.Button();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.maskedTextBox2 = new System.Windows.Forms.MaskedTextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.maskedTextBox1 = new System.Windows.Forms.MaskedTextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnApplicantContact = new System.Windows.Forms.Button();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnPropertyContact = new System.Windows.Forms.Button();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.btnNext = new System.Windows.Forms.Button();
            this.Title = new System.Windows.Forms.Label();
            this.Contractors = new System.Windows.Forms.TabPage();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.label68 = new System.Windows.Forms.Label();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.label57 = new System.Windows.Forms.Label();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.label58 = new System.Windows.Forms.Label();
            this.textBox46 = new System.Windows.Forms.TextBox();
            this.label59 = new System.Windows.Forms.Label();
            this.textBox47 = new System.Windows.Forms.TextBox();
            this.label60 = new System.Windows.Forms.Label();
            this.textBox48 = new System.Windows.Forms.TextBox();
            this.label61 = new System.Windows.Forms.Label();
            this.textBox49 = new System.Windows.Forms.TextBox();
            this.label62 = new System.Windows.Forms.Label();
            this.textBox50 = new System.Windows.Forms.TextBox();
            this.label63 = new System.Windows.Forms.Label();
            this.textBox51 = new System.Windows.Forms.TextBox();
            this.label64 = new System.Windows.Forms.Label();
            this.textBox53 = new System.Windows.Forms.TextBox();
            this.label72 = new System.Windows.Forms.Label();
            this.textBox54 = new System.Windows.Forms.TextBox();
            this.label73 = new System.Windows.Forms.Label();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.label14 = new System.Windows.Forms.Label();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.label75 = new System.Windows.Forms.Label();
            this.radioButton12 = new System.Windows.Forms.RadioButton();
            this.textBox55 = new System.Windows.Forms.TextBox();
            this.label78 = new System.Windows.Forms.Label();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.textBox57 = new System.Windows.Forms.TextBox();
            this.label109 = new System.Windows.Forms.Label();
            this.textBox58 = new System.Windows.Forms.TextBox();
            this.label110 = new System.Windows.Forms.Label();
            this.textBox60 = new System.Windows.Forms.TextBox();
            this.label112 = new System.Windows.Forms.Label();
            this.textBox61 = new System.Windows.Forms.TextBox();
            this.label113 = new System.Windows.Forms.Label();
            this.textBox62 = new System.Windows.Forms.TextBox();
            this.label114 = new System.Windows.Forms.Label();
            this.textBox63 = new System.Windows.Forms.TextBox();
            this.label115 = new System.Windows.Forms.Label();
            this.btnNext2 = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.maskedTextBox9 = new System.Windows.Forms.MaskedTextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.btnIrrigationContact = new System.Windows.Forms.Button();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.maskedTextBox8 = new System.Windows.Forms.MaskedTextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.btngasContact = new System.Windows.Forms.Button();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.maskedTextBox7 = new System.Windows.Forms.MaskedTextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.btnMechanicalContact = new System.Windows.Forms.Button();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.maskedTextBox6 = new System.Windows.Forms.MaskedTextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.btnPlumbingContact = new System.Windows.Forms.Button();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnContractorContact = new System.Windows.Forms.Button();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.maskedTextBox5 = new System.Windows.Forms.MaskedTextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.maskedTextBox4 = new System.Windows.Forms.MaskedTextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.textBox92 = new System.Windows.Forms.TextBox();
            this.label105 = new System.Windows.Forms.Label();
            this.textBox93 = new System.Windows.Forms.TextBox();
            this.label106 = new System.Windows.Forms.Label();
            this.textBox94 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.maskedTextBox3 = new System.Windows.Forms.MaskedTextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.btnElectricalContact = new System.Windows.Forms.Button();
            this.textBox82 = new System.Windows.Forms.TextBox();
            this.label95 = new System.Windows.Forms.Label();
            this.textBox83 = new System.Windows.Forms.TextBox();
            this.btnNext3 = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnCancelNotes = new System.Windows.Forms.Button();
            this.btnSubmitNotes = new System.Windows.Forms.Button();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.label25 = new System.Windows.Forms.Label();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox19.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.Contractors.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.Contractors);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(723, 493);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox19);
            this.tabPage1.Controls.Add(this.groupBox18);
            this.tabPage1.Controls.Add(this.groupBox14);
            this.tabPage1.Controls.Add(this.groupBox13);
            this.tabPage1.Controls.Add(this.groupBox12);
            this.tabPage1.Controls.Add(this.btnNext);
            this.tabPage1.Controls.Add(this.Title);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(715, 467);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Property Info";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox19
            // 
            this.groupBox19.Controls.Add(this.label24);
            this.groupBox19.Controls.Add(this.dateTimePicker3);
            this.groupBox19.Controls.Add(this.label23);
            this.groupBox19.Controls.Add(this.label22);
            this.groupBox19.Controls.Add(this.dateTimePicker2);
            this.groupBox19.Controls.Add(this.dateTimePicker1);
            this.groupBox19.Controls.Add(this.label21);
            this.groupBox19.Controls.Add(this.comboBox1);
            this.groupBox19.Controls.Add(this.textBox8);
            this.groupBox19.Controls.Add(this.label20);
            this.groupBox19.Controls.Add(this.textBox2);
            this.groupBox19.Controls.Add(this.label19);
            this.groupBox19.Location = new System.Drawing.Point(535, 38);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Size = new System.Drawing.Size(169, 177);
            this.groupBox19.TabIndex = 203;
            this.groupBox19.TabStop = false;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(17, 151);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(56, 13);
            this.label24.TabIndex = 182;
            this.label24.Text = "Issue date";
            // 
            // dateTimePicker3
            // 
            this.dateTimePicker3.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker3.Location = new System.Drawing.Point(79, 145);
            this.dateTimePicker3.Name = "dateTimePicker3";
            this.dateTimePicker3.Size = new System.Drawing.Size(84, 20);
            this.dateTimePicker3.TabIndex = 181;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(24, 125);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(50, 13);
            this.label23.TabIndex = 180;
            this.label23.Text = "End date";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(20, 99);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(53, 13);
            this.label22.TabIndex = 179;
            this.label22.Text = "Start date";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker2.Location = new System.Drawing.Point(79, 119);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(84, 20);
            this.dateTimePicker2.TabIndex = 178;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(79, 93);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(84, 20);
            this.dateTimePicker1.TabIndex = 177;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(36, 69);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(37, 13);
            this.label21.TabIndex = 176;
            this.label21.Text = "Status";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(79, 66);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(84, 21);
            this.comboBox1.TabIndex = 175;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(79, 40);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(84, 20);
            this.textBox8.TabIndex = 174;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(5, 43);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(69, 13);
            this.label20.TabIndex = 173;
            this.label20.Text = "Application #";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(79, 14);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(84, 20);
            this.textBox2.TabIndex = 172;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(27, 17);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(46, 13);
            this.label19.TabIndex = 171;
            this.label19.Text = "Permit #";
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.textBox15);
            this.groupBox18.Controls.Add(this.btnFees);
            this.groupBox18.Location = new System.Drawing.Point(535, 226);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(169, 86);
            this.groupBox18.TabIndex = 202;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "Balance";
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(51, 26);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(100, 20);
            this.textBox15.TabIndex = 201;
            // 
            // btnFees
            // 
            this.btnFees.Location = new System.Drawing.Point(124, 52);
            this.btnFees.Name = "btnFees";
            this.btnFees.Size = new System.Drawing.Size(27, 20);
            this.btnFees.TabIndex = 199;
            this.btnFees.Text = "...";
            this.btnFees.UseVisualStyleBackColor = true;
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.maskedTextBox10);
            this.groupBox14.Controls.Add(this.label1);
            this.groupBox14.Controls.Add(this.maskedTextBox11);
            this.groupBox14.Controls.Add(this.label12);
            this.groupBox14.Controls.Add(this.textBox1);
            this.groupBox14.Controls.Add(this.label13);
            this.groupBox14.Controls.Add(this.btnOwnerContact);
            this.groupBox14.Location = new System.Drawing.Point(20, 340);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(493, 100);
            this.groupBox14.TabIndex = 199;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "Owner Information";
            // 
            // maskedTextBox10
            // 
            this.maskedTextBox10.Location = new System.Drawing.Point(348, 59);
            this.maskedTextBox10.Mask = "(999) 000-0000";
            this.maskedTextBox10.Name = "maskedTextBox10";
            this.maskedTextBox10.Size = new System.Drawing.Size(100, 20);
            this.maskedTextBox10.TabIndex = 198;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(286, 64);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 13);
            this.label1.TabIndex = 197;
            this.label1.Text = "Cell #";
            // 
            // maskedTextBox11
            // 
            this.maskedTextBox11.Location = new System.Drawing.Point(107, 57);
            this.maskedTextBox11.Mask = "(999) 000-0000";
            this.maskedTextBox11.Name = "maskedTextBox11";
            this.maskedTextBox11.Size = new System.Drawing.Size(100, 20);
            this.maskedTextBox11.TabIndex = 196;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(8, 60);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(85, 13);
            this.label12.TabIndex = 195;
            this.label12.Text = "Primary Phone #";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(70, 19);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(378, 20);
            this.textBox1.TabIndex = 177;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(11, 22);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(60, 13);
            this.label13.TabIndex = 176;
            this.label13.Text = "Applicant";
            // 
            // btnOwnerContact
            // 
            this.btnOwnerContact.Location = new System.Drawing.Point(454, 18);
            this.btnOwnerContact.Name = "btnOwnerContact";
            this.btnOwnerContact.Size = new System.Drawing.Size(27, 20);
            this.btnOwnerContact.TabIndex = 178;
            this.btnOwnerContact.Text = "...";
            this.btnOwnerContact.UseVisualStyleBackColor = true;
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.maskedTextBox2);
            this.groupBox13.Controls.Add(this.label11);
            this.groupBox13.Controls.Add(this.maskedTextBox1);
            this.groupBox13.Controls.Add(this.label10);
            this.groupBox13.Controls.Add(this.textBox3);
            this.groupBox13.Controls.Add(this.label2);
            this.groupBox13.Controls.Add(this.btnApplicantContact);
            this.groupBox13.Location = new System.Drawing.Point(20, 222);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(493, 100);
            this.groupBox13.TabIndex = 192;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Applicant Information";
            // 
            // maskedTextBox2
            // 
            this.maskedTextBox2.Location = new System.Drawing.Point(348, 59);
            this.maskedTextBox2.Mask = "(999) 000-0000";
            this.maskedTextBox2.Name = "maskedTextBox2";
            this.maskedTextBox2.Size = new System.Drawing.Size(100, 20);
            this.maskedTextBox2.TabIndex = 198;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(286, 64);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(34, 13);
            this.label11.TabIndex = 197;
            this.label11.Text = "Cell #";
            // 
            // maskedTextBox1
            // 
            this.maskedTextBox1.Location = new System.Drawing.Point(107, 57);
            this.maskedTextBox1.Mask = "(999) 000-0000";
            this.maskedTextBox1.Name = "maskedTextBox1";
            this.maskedTextBox1.Size = new System.Drawing.Size(100, 20);
            this.maskedTextBox1.TabIndex = 196;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(8, 60);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(85, 13);
            this.label10.TabIndex = 195;
            this.label10.Text = "Primary Phone #";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(70, 19);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(378, 20);
            this.textBox3.TabIndex = 177;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(11, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 13);
            this.label2.TabIndex = 176;
            this.label2.Text = "Applicant";
            // 
            // btnApplicantContact
            // 
            this.btnApplicantContact.Location = new System.Drawing.Point(454, 18);
            this.btnApplicantContact.Name = "btnApplicantContact";
            this.btnApplicantContact.Size = new System.Drawing.Size(27, 20);
            this.btnApplicantContact.TabIndex = 178;
            this.btnApplicantContact.Text = "...";
            this.btnApplicantContact.UseVisualStyleBackColor = true;
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.comboBox4);
            this.groupBox12.Controls.Add(this.comboBox3);
            this.groupBox12.Controls.Add(this.comboBox2);
            this.groupBox12.Controls.Add(this.textBox12);
            this.groupBox12.Controls.Add(this.label8);
            this.groupBox12.Controls.Add(this.textBox9);
            this.groupBox12.Controls.Add(this.label7);
            this.groupBox12.Controls.Add(this.textBox7);
            this.groupBox12.Controls.Add(this.label6);
            this.groupBox12.Controls.Add(this.textBox6);
            this.groupBox12.Controls.Add(this.label5);
            this.groupBox12.Controls.Add(this.textBox5);
            this.groupBox12.Controls.Add(this.label4);
            this.groupBox12.Controls.Add(this.textBox4);
            this.groupBox12.Controls.Add(this.label3);
            this.groupBox12.Controls.Add(this.btnPropertyContact);
            this.groupBox12.Controls.Add(this.textBox10);
            this.groupBox12.Controls.Add(this.label9);
            this.groupBox12.Location = new System.Drawing.Point(20, 38);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(493, 177);
            this.groupBox12.TabIndex = 191;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Property Information";
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(339, 137);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(121, 21);
            this.comboBox4.TabIndex = 210;
            this.comboBox4.Text = "Proposed Use";
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(180, 137);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(121, 21);
            this.comboBox3.TabIndex = 209;
            this.comboBox3.Text = "Current Use";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(20, 137);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 21);
            this.comboBox2.TabIndex = 208;
            this.comboBox2.Text = "Occupancy Type";
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(333, 107);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(95, 20);
            this.textBox12.TabIndex = 205;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(237, 110);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(83, 13);
            this.label8.TabIndex = 204;
            this.label8.Text = "Side Setback";
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(333, 78);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(95, 20);
            this.textBox9.TabIndex = 203;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(237, 81);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(85, 13);
            this.label7.TabIndex = 202;
            this.label7.Text = "Rear Setback";
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(107, 104);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(95, 20);
            this.textBox7.TabIndex = 201;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(11, 107);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(87, 13);
            this.label6.TabIndex = 200;
            this.label6.Text = "Front Setback";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(107, 78);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(95, 20);
            this.textBox6.TabIndex = 199;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(11, 81);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 13);
            this.label5.TabIndex = 198;
            this.label5.Text = "Zoning District";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(251, 49);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(95, 20);
            this.textBox5.TabIndex = 197;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(192, 52);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(43, 13);
            this.label4.TabIndex = 196;
            this.label4.Text = "LRK #";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(70, 49);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(95, 20);
            this.textBox4.TabIndex = 195;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(11, 52);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 13);
            this.label3.TabIndex = 194;
            this.label3.Text = "Lot #";
            // 
            // btnPropertyContact
            // 
            this.btnPropertyContact.Location = new System.Drawing.Point(454, 22);
            this.btnPropertyContact.Name = "btnPropertyContact";
            this.btnPropertyContact.Size = new System.Drawing.Size(27, 20);
            this.btnPropertyContact.TabIndex = 193;
            this.btnPropertyContact.Text = "...";
            this.btnPropertyContact.UseVisualStyleBackColor = true;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(70, 23);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(378, 20);
            this.textBox10.TabIndex = 192;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(11, 26);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(54, 13);
            this.label9.TabIndex = 191;
            this.label9.Text = "Property";
            // 
            // btnNext
            // 
            this.btnNext.Location = new System.Drawing.Point(623, 417);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(75, 23);
            this.btnNext.TabIndex = 154;
            this.btnNext.Text = "Next";
            this.btnNext.UseVisualStyleBackColor = true;
            // 
            // Title
            // 
            this.Title.AutoSize = true;
            this.Title.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Title.Location = new System.Drawing.Point(3, 3);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(376, 26);
            this.Title.TabIndex = 106;
            this.Title.Text = "Town Of Aberdeen Permit Application";
            // 
            // Contractors
            // 
            this.Contractors.Controls.Add(this.groupBox6);
            this.Contractors.Controls.Add(this.groupBox8);
            this.Contractors.Controls.Add(this.groupBox17);
            this.Contractors.Controls.Add(this.groupBox10);
            this.Contractors.Controls.Add(this.groupBox15);
            this.Contractors.Controls.Add(this.btnNext2);
            this.Contractors.Location = new System.Drawing.Point(4, 22);
            this.Contractors.Name = "Contractors";
            this.Contractors.Padding = new System.Windows.Forms.Padding(3);
            this.Contractors.Size = new System.Drawing.Size(715, 467);
            this.Contractors.TabIndex = 2;
            this.Contractors.Text = "Construction Info";
            this.Contractors.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.textBox13);
            this.groupBox6.Controls.Add(this.label16);
            this.groupBox6.Controls.Add(this.groupBox7);
            this.groupBox6.Location = new System.Drawing.Point(39, 383);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(473, 62);
            this.groupBox6.TabIndex = 222;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Electrical";
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(84, 25);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(62, 20);
            this.textBox13.TabIndex = 228;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(12, 28);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(55, 13);
            this.label16.TabIndex = 227;
            this.label16.Text = "# of Amps";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.label68);
            this.groupBox7.Controls.Add(this.radioButton7);
            this.groupBox7.Location = new System.Drawing.Point(224, 12);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(122, 37);
            this.groupBox7.TabIndex = 226;
            this.groupBox7.TabStop = false;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(6, 13);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(81, 13);
            this.label68.TabIndex = 1;
            this.label68.Text = "Temporary Pole";
            // 
            // radioButton7
            // 
            this.radioButton7.AutoSize = true;
            this.radioButton7.Location = new System.Drawing.Point(94, 14);
            this.radioButton7.Name = "radioButton7";
            this.radioButton7.Size = new System.Drawing.Size(14, 13);
            this.radioButton7.TabIndex = 0;
            this.radioButton7.TabStop = true;
            this.radioButton7.UseVisualStyleBackColor = true;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.textBox43);
            this.groupBox8.Controls.Add(this.label56);
            this.groupBox8.Controls.Add(this.textBox44);
            this.groupBox8.Controls.Add(this.label57);
            this.groupBox8.Controls.Add(this.textBox45);
            this.groupBox8.Controls.Add(this.label58);
            this.groupBox8.Controls.Add(this.textBox46);
            this.groupBox8.Controls.Add(this.label59);
            this.groupBox8.Controls.Add(this.textBox47);
            this.groupBox8.Controls.Add(this.label60);
            this.groupBox8.Controls.Add(this.textBox48);
            this.groupBox8.Controls.Add(this.label61);
            this.groupBox8.Controls.Add(this.textBox49);
            this.groupBox8.Controls.Add(this.label62);
            this.groupBox8.Controls.Add(this.textBox50);
            this.groupBox8.Controls.Add(this.label63);
            this.groupBox8.Controls.Add(this.textBox51);
            this.groupBox8.Controls.Add(this.label64);
            this.groupBox8.Controls.Add(this.textBox53);
            this.groupBox8.Controls.Add(this.label72);
            this.groupBox8.Controls.Add(this.textBox54);
            this.groupBox8.Controls.Add(this.label73);
            this.groupBox8.Location = new System.Drawing.Point(39, 252);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(473, 125);
            this.groupBox8.TabIndex = 221;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Plumbing";
            // 
            // textBox43
            // 
            this.textBox43.Location = new System.Drawing.Point(119, 95);
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new System.Drawing.Size(27, 20);
            this.textBox43.TabIndex = 238;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(41, 98);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(71, 13);
            this.label56.TabIndex = 237;
            this.label56.Text = "Water Heater";
            // 
            // textBox44
            // 
            this.textBox44.Location = new System.Drawing.Point(395, 74);
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new System.Drawing.Size(27, 20);
            this.textBox44.TabIndex = 236;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(362, 77);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(26, 13);
            this.label57.TabIndex = 234;
            this.label57.Text = "Spa";
            // 
            // textBox45
            // 
            this.textBox45.Location = new System.Drawing.Point(267, 95);
            this.textBox45.Name = "textBox45";
            this.textBox45.Size = new System.Drawing.Size(28, 20);
            this.textBox45.TabIndex = 235;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(213, 98);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(46, 13);
            this.label58.TabIndex = 233;
            this.label58.Text = "Wet Bar";
            // 
            // textBox46
            // 
            this.textBox46.Location = new System.Drawing.Point(119, 69);
            this.textBox46.Name = "textBox46";
            this.textBox46.Size = new System.Drawing.Size(27, 20);
            this.textBox46.TabIndex = 232;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(50, 72);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(62, 13);
            this.label59.TabIndex = 231;
            this.label59.Text = "Dishwasher";
            // 
            // textBox47
            // 
            this.textBox47.Location = new System.Drawing.Point(394, 48);
            this.textBox47.Name = "textBox47";
            this.textBox47.Size = new System.Drawing.Size(27, 20);
            this.textBox47.TabIndex = 230;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(299, 51);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(87, 13);
            this.label60.TabIndex = 229;
            this.label60.Text = "Clothes Washers";
            // 
            // textBox48
            // 
            this.textBox48.Location = new System.Drawing.Point(267, 69);
            this.textBox48.Name = "textBox48";
            this.textBox48.Size = new System.Drawing.Size(27, 20);
            this.textBox48.TabIndex = 228;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(229, 72);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(31, 13);
            this.label61.TabIndex = 226;
            this.label61.Text = "Tubs";
            // 
            // textBox49
            // 
            this.textBox49.Location = new System.Drawing.Point(267, 45);
            this.textBox49.Name = "textBox49";
            this.textBox49.Size = new System.Drawing.Size(28, 20);
            this.textBox49.TabIndex = 227;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(211, 48);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(48, 13);
            this.label62.TabIndex = 225;
            this.label62.Text = "Showers";
            // 
            // textBox50
            // 
            this.textBox50.Location = new System.Drawing.Point(119, 45);
            this.textBox50.Name = "textBox50";
            this.textBox50.Size = new System.Drawing.Size(27, 20);
            this.textBox50.TabIndex = 224;
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(39, 48);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(73, 13);
            this.label63.TabIndex = 222;
            this.label63.Text = "Water Closets";
            // 
            // textBox51
            // 
            this.textBox51.Location = new System.Drawing.Point(395, 22);
            this.textBox51.Name = "textBox51";
            this.textBox51.Size = new System.Drawing.Size(26, 20);
            this.textBox51.TabIndex = 223;
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(353, 25);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(33, 13);
            this.label64.TabIndex = 221;
            this.label64.Text = "Sinks";
            // 
            // textBox53
            // 
            this.textBox53.Location = new System.Drawing.Point(119, 22);
            this.textBox53.Name = "textBox53";
            this.textBox53.Size = new System.Drawing.Size(27, 20);
            this.textBox53.TabIndex = 220;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(7, 25);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(106, 13);
            this.label72.TabIndex = 218;
            this.label72.Text = "Total # of Bathrooms";
            // 
            // textBox54
            // 
            this.textBox54.Location = new System.Drawing.Point(267, 22);
            this.textBox54.Name = "textBox54";
            this.textBox54.Size = new System.Drawing.Size(28, 20);
            this.textBox54.TabIndex = 219;
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(167, 25);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(92, 13);
            this.label73.TabIndex = 217;
            this.label73.Text = "Total # of Fixtures";
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.groupBox16);
            this.groupBox17.Controls.Add(this.groupBox9);
            this.groupBox17.Controls.Add(this.textBox55);
            this.groupBox17.Controls.Add(this.label78);
            this.groupBox17.Location = new System.Drawing.Point(37, 168);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(593, 77);
            this.groupBox17.TabIndex = 220;
            this.groupBox17.TabStop = false;
            this.groupBox17.Text = "Heating/Air Conditioning/Mechanical";
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.label14);
            this.groupBox16.Controls.Add(this.radioButton1);
            this.groupBox16.Location = new System.Drawing.Point(213, 20);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(89, 37);
            this.groupBox16.TabIndex = 190;
            this.groupBox16.TabStop = false;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(12, 15);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(49, 13);
            this.label14.TabIndex = 1;
            this.label14.Text = "Gas Line";
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(67, 15);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(14, 13);
            this.radioButton1.TabIndex = 0;
            this.radioButton1.TabStop = true;
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.label75);
            this.groupBox9.Controls.Add(this.radioButton12);
            this.groupBox9.Location = new System.Drawing.Point(355, 20);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(195, 37);
            this.groupBox9.TabIndex = 189;
            this.groupBox9.TabStop = false;
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(6, 16);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(145, 13);
            this.label75.TabIndex = 1;
            this.label75.Text = "Duct Work for Alteration Only";
            // 
            // radioButton12
            // 
            this.radioButton12.AutoSize = true;
            this.radioButton12.Location = new System.Drawing.Point(167, 16);
            this.radioButton12.Name = "radioButton12";
            this.radioButton12.Size = new System.Drawing.Size(14, 13);
            this.radioButton12.TabIndex = 0;
            this.radioButton12.TabStop = true;
            this.radioButton12.UseVisualStyleBackColor = true;
            // 
            // textBox55
            // 
            this.textBox55.Location = new System.Drawing.Point(113, 29);
            this.textBox55.Name = "textBox55";
            this.textBox55.Size = new System.Drawing.Size(56, 20);
            this.textBox55.TabIndex = 188;
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Location = new System.Drawing.Point(9, 32);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(98, 13);
            this.label78.TabIndex = 187;
            this.label78.Text = "Number of Systems";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.comboBox5);
            this.groupBox10.Controls.Add(this.textBox14);
            this.groupBox10.Controls.Add(this.label15);
            this.groupBox10.Controls.Add(this.textBox18);
            this.groupBox10.Controls.Add(this.label39);
            this.groupBox10.Location = new System.Drawing.Point(35, 6);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(595, 58);
            this.groupBox10.TabIndex = 219;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "General";
            // 
            // comboBox5
            // 
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Location = new System.Drawing.Point(409, 19);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(143, 21);
            this.comboBox5.TabIndex = 209;
            this.comboBox5.Text = "Type of Construction";
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(277, 20);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(101, 20);
            this.textBox14.TabIndex = 185;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(195, 23);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(77, 13);
            this.label15.TabIndex = 177;
            this.label15.Text = "Estimated Cost";
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(100, 19);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(82, 20);
            this.textBox18.TabIndex = 184;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(23, 23);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(65, 13);
            this.label39.TabIndex = 176;
            this.label39.Text = "Square Feet";
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.textBox57);
            this.groupBox15.Controls.Add(this.label109);
            this.groupBox15.Controls.Add(this.textBox58);
            this.groupBox15.Controls.Add(this.label110);
            this.groupBox15.Controls.Add(this.textBox60);
            this.groupBox15.Controls.Add(this.label112);
            this.groupBox15.Controls.Add(this.textBox61);
            this.groupBox15.Controls.Add(this.label113);
            this.groupBox15.Controls.Add(this.textBox62);
            this.groupBox15.Controls.Add(this.label114);
            this.groupBox15.Controls.Add(this.textBox63);
            this.groupBox15.Controls.Add(this.label115);
            this.groupBox15.Location = new System.Drawing.Point(35, 70);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(595, 91);
            this.groupBox15.TabIndex = 218;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "Building";
            // 
            // textBox57
            // 
            this.textBox57.Location = new System.Drawing.Point(87, 51);
            this.textBox57.Name = "textBox57";
            this.textBox57.Size = new System.Drawing.Size(87, 20);
            this.textBox57.TabIndex = 186;
            // 
            // label109
            // 
            this.label109.AutoSize = true;
            this.label109.Location = new System.Drawing.Point(48, 55);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(33, 13);
            this.label109.TabIndex = 181;
            this.label109.Text = "Deck";
            // 
            // textBox58
            // 
            this.textBox58.Location = new System.Drawing.Point(252, 14);
            this.textBox58.Name = "textBox58";
            this.textBox58.Size = new System.Drawing.Size(100, 20);
            this.textBox58.TabIndex = 185;
            // 
            // label110
            // 
            this.label110.AutoSize = true;
            this.label110.Location = new System.Drawing.Point(195, 17);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(51, 13);
            this.label110.TabIndex = 177;
            this.label110.Text = "Porch SF";
            // 
            // textBox60
            // 
            this.textBox60.Location = new System.Drawing.Point(436, 51);
            this.textBox60.Name = "textBox60";
            this.textBox60.Size = new System.Drawing.Size(100, 20);
            this.textBox60.TabIndex = 189;
            // 
            // label112
            // 
            this.label112.AutoSize = true;
            this.label112.Location = new System.Drawing.Point(376, 54);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(54, 13);
            this.label112.TabIndex = 180;
            this.label112.Text = "Basement";
            // 
            // textBox61
            // 
            this.textBox61.Location = new System.Drawing.Point(252, 51);
            this.textBox61.Name = "textBox61";
            this.textBox61.Size = new System.Drawing.Size(100, 20);
            this.textBox61.TabIndex = 188;
            // 
            // label113
            // 
            this.label113.AutoSize = true;
            this.label113.Location = new System.Drawing.Point(188, 54);
            this.label113.Name = "label113";
            this.label113.Size = new System.Drawing.Size(58, 13);
            this.label113.TabIndex = 179;
            this.label113.Text = "Garage SF";
            // 
            // textBox62
            // 
            this.textBox62.Location = new System.Drawing.Point(458, 14);
            this.textBox62.Name = "textBox62";
            this.textBox62.Size = new System.Drawing.Size(78, 20);
            this.textBox62.TabIndex = 187;
            // 
            // label114
            // 
            this.label114.AutoSize = true;
            this.label114.Location = new System.Drawing.Point(371, 14);
            this.label114.Name = "label114";
            this.label114.Size = new System.Drawing.Size(61, 13);
            this.label114.TabIndex = 178;
            this.label114.Text = "# of Stories";
            // 
            // textBox63
            // 
            this.textBox63.Location = new System.Drawing.Point(87, 14);
            this.textBox63.Name = "textBox63";
            this.textBox63.Size = new System.Drawing.Size(87, 20);
            this.textBox63.TabIndex = 184;
            // 
            // label115
            // 
            this.label115.AutoSize = true;
            this.label115.Location = new System.Drawing.Point(23, 17);
            this.label115.Name = "label115";
            this.label115.Size = new System.Drawing.Size(58, 13);
            this.label115.TabIndex = 176;
            this.label115.Text = "Heated SF";
            // 
            // btnNext2
            // 
            this.btnNext2.Location = new System.Drawing.Point(600, 403);
            this.btnNext2.Name = "btnNext2";
            this.btnNext2.Size = new System.Drawing.Size(75, 23);
            this.btnNext2.TabIndex = 217;
            this.btnNext2.Text = "Next";
            this.btnNext2.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.groupBox11);
            this.tabPage3.Controls.Add(this.groupBox5);
            this.tabPage3.Controls.Add(this.groupBox4);
            this.tabPage3.Controls.Add(this.groupBox3);
            this.tabPage3.Controls.Add(this.groupBox2);
            this.tabPage3.Controls.Add(this.groupBox1);
            this.tabPage3.Controls.Add(this.btnNext3);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(715, 467);
            this.tabPage3.TabIndex = 3;
            this.tabPage3.Text = "Contractors";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.maskedTextBox9);
            this.groupBox11.Controls.Add(this.label37);
            this.groupBox11.Controls.Add(this.btnIrrigationContact);
            this.groupBox11.Controls.Add(this.textBox26);
            this.groupBox11.Controls.Add(this.label38);
            this.groupBox11.Controls.Add(this.textBox27);
            this.groupBox11.Location = new System.Drawing.Point(20, 321);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(647, 41);
            this.groupBox11.TabIndex = 195;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Irrigation Sub";
            // 
            // maskedTextBox9
            // 
            this.maskedTextBox9.Location = new System.Drawing.Point(473, 14);
            this.maskedTextBox9.Mask = "(999) 000-0000";
            this.maskedTextBox9.Name = "maskedTextBox9";
            this.maskedTextBox9.Size = new System.Drawing.Size(100, 20);
            this.maskedTextBox9.TabIndex = 194;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(411, 19);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(48, 13);
            this.label37.TabIndex = 193;
            this.label37.Text = "Phone #";
            // 
            // btnIrrigationContact
            // 
            this.btnIrrigationContact.Location = new System.Drawing.Point(614, 14);
            this.btnIrrigationContact.Name = "btnIrrigationContact";
            this.btnIrrigationContact.Size = new System.Drawing.Size(27, 20);
            this.btnIrrigationContact.TabIndex = 192;
            this.btnIrrigationContact.Text = "...";
            this.btnIrrigationContact.UseVisualStyleBackColor = true;
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(310, 13);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(89, 20);
            this.textBox26.TabIndex = 191;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(248, 17);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(54, 13);
            this.label38.TabIndex = 189;
            this.label38.Text = "License#:";
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(6, 14);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(227, 20);
            this.textBox27.TabIndex = 190;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.maskedTextBox8);
            this.groupBox5.Controls.Add(this.label35);
            this.groupBox5.Controls.Add(this.btngasContact);
            this.groupBox5.Controls.Add(this.textBox24);
            this.groupBox5.Controls.Add(this.label36);
            this.groupBox5.Controls.Add(this.textBox25);
            this.groupBox5.Location = new System.Drawing.Point(20, 274);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(647, 41);
            this.groupBox5.TabIndex = 193;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Gas Line Sub";
            // 
            // maskedTextBox8
            // 
            this.maskedTextBox8.Location = new System.Drawing.Point(473, 14);
            this.maskedTextBox8.Mask = "(999) 000-0000";
            this.maskedTextBox8.Name = "maskedTextBox8";
            this.maskedTextBox8.Size = new System.Drawing.Size(100, 20);
            this.maskedTextBox8.TabIndex = 194;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(411, 19);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(48, 13);
            this.label35.TabIndex = 193;
            this.label35.Text = "Phone #";
            // 
            // btngasContact
            // 
            this.btngasContact.Location = new System.Drawing.Point(614, 14);
            this.btngasContact.Name = "btngasContact";
            this.btngasContact.Size = new System.Drawing.Size(27, 20);
            this.btngasContact.TabIndex = 192;
            this.btngasContact.Text = "...";
            this.btngasContact.UseVisualStyleBackColor = true;
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(310, 13);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(89, 20);
            this.textBox24.TabIndex = 191;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(248, 17);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(54, 13);
            this.label36.TabIndex = 189;
            this.label36.Text = "License#:";
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(6, 14);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(227, 20);
            this.textBox25.TabIndex = 190;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.maskedTextBox7);
            this.groupBox4.Controls.Add(this.label33);
            this.groupBox4.Controls.Add(this.btnMechanicalContact);
            this.groupBox4.Controls.Add(this.textBox22);
            this.groupBox4.Controls.Add(this.label34);
            this.groupBox4.Controls.Add(this.textBox23);
            this.groupBox4.Location = new System.Drawing.Point(20, 227);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(647, 41);
            this.groupBox4.TabIndex = 192;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Mechanical Sub";
            // 
            // maskedTextBox7
            // 
            this.maskedTextBox7.Location = new System.Drawing.Point(473, 14);
            this.maskedTextBox7.Mask = "(999) 000-0000";
            this.maskedTextBox7.Name = "maskedTextBox7";
            this.maskedTextBox7.Size = new System.Drawing.Size(100, 20);
            this.maskedTextBox7.TabIndex = 194;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(411, 19);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(48, 13);
            this.label33.TabIndex = 193;
            this.label33.Text = "Phone #";
            // 
            // btnMechanicalContact
            // 
            this.btnMechanicalContact.Location = new System.Drawing.Point(614, 14);
            this.btnMechanicalContact.Name = "btnMechanicalContact";
            this.btnMechanicalContact.Size = new System.Drawing.Size(27, 20);
            this.btnMechanicalContact.TabIndex = 192;
            this.btnMechanicalContact.Text = "...";
            this.btnMechanicalContact.UseVisualStyleBackColor = true;
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(310, 13);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(89, 20);
            this.textBox22.TabIndex = 191;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(248, 17);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(54, 13);
            this.label34.TabIndex = 189;
            this.label34.Text = "License#:";
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(6, 14);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(227, 20);
            this.textBox23.TabIndex = 190;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.maskedTextBox6);
            this.groupBox3.Controls.Add(this.label31);
            this.groupBox3.Controls.Add(this.btnPlumbingContact);
            this.groupBox3.Controls.Add(this.textBox20);
            this.groupBox3.Controls.Add(this.label32);
            this.groupBox3.Controls.Add(this.textBox21);
            this.groupBox3.Location = new System.Drawing.Point(20, 180);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(647, 41);
            this.groupBox3.TabIndex = 191;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Plumbing Sub";
            // 
            // maskedTextBox6
            // 
            this.maskedTextBox6.Location = new System.Drawing.Point(473, 14);
            this.maskedTextBox6.Mask = "(999) 000-0000";
            this.maskedTextBox6.Name = "maskedTextBox6";
            this.maskedTextBox6.Size = new System.Drawing.Size(100, 20);
            this.maskedTextBox6.TabIndex = 194;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(411, 19);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(48, 13);
            this.label31.TabIndex = 193;
            this.label31.Text = "Phone #";
            // 
            // btnPlumbingContact
            // 
            this.btnPlumbingContact.Location = new System.Drawing.Point(614, 14);
            this.btnPlumbingContact.Name = "btnPlumbingContact";
            this.btnPlumbingContact.Size = new System.Drawing.Size(27, 20);
            this.btnPlumbingContact.TabIndex = 192;
            this.btnPlumbingContact.Text = "...";
            this.btnPlumbingContact.UseVisualStyleBackColor = true;
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(310, 13);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(89, 20);
            this.textBox20.TabIndex = 191;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(248, 17);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(54, 13);
            this.label32.TabIndex = 189;
            this.label32.Text = "License#:";
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(6, 14);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(227, 20);
            this.textBox21.TabIndex = 190;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnContractorContact);
            this.groupBox2.Controls.Add(this.textBox19);
            this.groupBox2.Controls.Add(this.label30);
            this.groupBox2.Controls.Add(this.maskedTextBox5);
            this.groupBox2.Controls.Add(this.label29);
            this.groupBox2.Controls.Add(this.label28);
            this.groupBox2.Controls.Add(this.maskedTextBox4);
            this.groupBox2.Controls.Add(this.label27);
            this.groupBox2.Controls.Add(this.textBox92);
            this.groupBox2.Controls.Add(this.label105);
            this.groupBox2.Controls.Add(this.textBox93);
            this.groupBox2.Controls.Add(this.label106);
            this.groupBox2.Controls.Add(this.textBox94);
            this.groupBox2.Location = new System.Drawing.Point(20, 24);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(647, 99);
            this.groupBox2.TabIndex = 190;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "General Contractor";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // btnContractorContact
            // 
            this.btnContractorContact.Location = new System.Drawing.Point(614, 69);
            this.btnContractorContact.Name = "btnContractorContact";
            this.btnContractorContact.Size = new System.Drawing.Size(27, 20);
            this.btnContractorContact.TabIndex = 202;
            this.btnContractorContact.Text = "...";
            this.btnContractorContact.UseVisualStyleBackColor = true;
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(518, 43);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(114, 20);
            this.textBox19.TabIndex = 201;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(472, 46);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(32, 13);
            this.label30.TabIndex = 200;
            this.label30.Text = "Email";
            // 
            // maskedTextBox5
            // 
            this.maskedTextBox5.Location = new System.Drawing.Point(344, 43);
            this.maskedTextBox5.Mask = "(999) 000-0000";
            this.maskedTextBox5.Name = "maskedTextBox5";
            this.maskedTextBox5.Size = new System.Drawing.Size(100, 20);
            this.maskedTextBox5.TabIndex = 199;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(282, 48);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(48, 13);
            this.label29.TabIndex = 198;
            this.label29.Text = "Phone #";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(2, 22);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(35, 13);
            this.label28.TabIndex = 197;
            this.label28.Text = "Name";
            // 
            // maskedTextBox4
            // 
            this.maskedTextBox4.Location = new System.Drawing.Point(532, 19);
            this.maskedTextBox4.Mask = "(999) 000-0000";
            this.maskedTextBox4.Name = "maskedTextBox4";
            this.maskedTextBox4.Size = new System.Drawing.Size(100, 20);
            this.maskedTextBox4.TabIndex = 196;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(470, 24);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(48, 13);
            this.label27.TabIndex = 195;
            this.label27.Text = "Phone #";
            // 
            // textBox92
            // 
            this.textBox92.Location = new System.Drawing.Point(75, 43);
            this.textBox92.Name = "textBox92";
            this.textBox92.Size = new System.Drawing.Size(191, 20);
            this.textBox92.TabIndex = 162;
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.Location = new System.Drawing.Point(3, 46);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(70, 13);
            this.label105.TabIndex = 159;
            this.label105.Text = "Site Manager";
            // 
            // textBox93
            // 
            this.textBox93.Location = new System.Drawing.Point(352, 17);
            this.textBox93.Name = "textBox93";
            this.textBox93.Size = new System.Drawing.Size(92, 20);
            this.textBox93.TabIndex = 161;
            // 
            // label106
            // 
            this.label106.AutoSize = true;
            this.label106.Location = new System.Drawing.Point(290, 21);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(51, 13);
            this.label106.TabIndex = 158;
            this.label106.Text = "License#";
            // 
            // textBox94
            // 
            this.textBox94.Location = new System.Drawing.Point(56, 18);
            this.textBox94.Name = "textBox94";
            this.textBox94.Size = new System.Drawing.Size(228, 20);
            this.textBox94.TabIndex = 160;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.maskedTextBox3);
            this.groupBox1.Controls.Add(this.label26);
            this.groupBox1.Controls.Add(this.btnElectricalContact);
            this.groupBox1.Controls.Add(this.textBox82);
            this.groupBox1.Controls.Add(this.label95);
            this.groupBox1.Controls.Add(this.textBox83);
            this.groupBox1.Location = new System.Drawing.Point(20, 133);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(647, 41);
            this.groupBox1.TabIndex = 189;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Electrical Sub";
            // 
            // maskedTextBox3
            // 
            this.maskedTextBox3.Location = new System.Drawing.Point(473, 14);
            this.maskedTextBox3.Mask = "(999) 000-0000";
            this.maskedTextBox3.Name = "maskedTextBox3";
            this.maskedTextBox3.Size = new System.Drawing.Size(100, 20);
            this.maskedTextBox3.TabIndex = 194;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(411, 19);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(48, 13);
            this.label26.TabIndex = 193;
            this.label26.Text = "Phone #";
            // 
            // btnElectricalContact
            // 
            this.btnElectricalContact.Location = new System.Drawing.Point(614, 14);
            this.btnElectricalContact.Name = "btnElectricalContact";
            this.btnElectricalContact.Size = new System.Drawing.Size(27, 20);
            this.btnElectricalContact.TabIndex = 192;
            this.btnElectricalContact.Text = "...";
            this.btnElectricalContact.UseVisualStyleBackColor = true;
            // 
            // textBox82
            // 
            this.textBox82.Location = new System.Drawing.Point(310, 13);
            this.textBox82.Name = "textBox82";
            this.textBox82.Size = new System.Drawing.Size(89, 20);
            this.textBox82.TabIndex = 191;
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Location = new System.Drawing.Point(248, 17);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(54, 13);
            this.label95.TabIndex = 189;
            this.label95.Text = "License#:";
            // 
            // textBox83
            // 
            this.textBox83.Location = new System.Drawing.Point(6, 14);
            this.textBox83.Name = "textBox83";
            this.textBox83.Size = new System.Drawing.Size(227, 20);
            this.textBox83.TabIndex = 190;
            // 
            // btnNext3
            // 
            this.btnNext3.Location = new System.Drawing.Point(592, 401);
            this.btnNext3.Name = "btnNext3";
            this.btnNext3.Size = new System.Drawing.Size(75, 23);
            this.btnNext3.TabIndex = 185;
            this.btnNext3.Text = "Next";
            this.btnNext3.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.btnCancelNotes);
            this.tabPage2.Controls.Add(this.btnSubmitNotes);
            this.tabPage2.Controls.Add(this.btnSubmit);
            this.tabPage2.Controls.Add(this.label25);
            this.tabPage2.Controls.Add(this.textBox11);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(715, 467);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Additonal Info";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // btnCancelNotes
            // 
            this.btnCancelNotes.Location = new System.Drawing.Point(185, 383);
            this.btnCancelNotes.Name = "btnCancelNotes";
            this.btnCancelNotes.Size = new System.Drawing.Size(75, 23);
            this.btnCancelNotes.TabIndex = 211;
            this.btnCancelNotes.Text = "Cancel";
            this.btnCancelNotes.UseVisualStyleBackColor = true;
            // 
            // btnSubmitNotes
            // 
            this.btnSubmitNotes.Location = new System.Drawing.Point(21, 383);
            this.btnSubmitNotes.Name = "btnSubmitNotes";
            this.btnSubmitNotes.Size = new System.Drawing.Size(134, 23);
            this.btnSubmitNotes.TabIndex = 210;
            this.btnSubmitNotes.Text = "Save Notes";
            this.btnSubmitNotes.UseVisualStyleBackColor = true;
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(632, 425);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(75, 23);
            this.btnSubmit.TabIndex = 158;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(8, 57);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(35, 13);
            this.label25.TabIndex = 157;
            this.label25.Text = "Notes";
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(6, 83);
            this.textBox11.Multiline = true;
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(701, 294);
            this.textBox11.TabIndex = 0;
            // 
            // BuildingPermitTabs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(726, 505);
            this.Controls.Add(this.tabControl1);
            this.Name = "BuildingPermitTabs";
            this.Text = "Town of Aberdeen Permit Application";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.groupBox19.ResumeLayout(false);
            this.groupBox19.PerformLayout();
            this.groupBox18.ResumeLayout(false);
            this.groupBox18.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.Contractors.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox17.ResumeLayout(false);
            this.groupBox17.PerformLayout();
            this.groupBox16.ResumeLayout(false);
            this.groupBox16.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox15.ResumeLayout(false);
            this.groupBox15.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.TabPage Contractors;
        private System.Windows.Forms.Button btnNext2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button btnNext3;
        private System.Windows.Forms.Button btnSubmit;
        internal System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.Button btnCancelNotes;
        private System.Windows.Forms.Button btnSubmitNotes;
        private System.Windows.Forms.GroupBox groupBox2;
        internal System.Windows.Forms.TextBox textBox92;
        internal System.Windows.Forms.Label label105;
        internal System.Windows.Forms.TextBox textBox93;
        internal System.Windows.Forms.Label label106;
        internal System.Windows.Forms.TextBox textBox94;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.MaskedTextBox maskedTextBox3;
        internal System.Windows.Forms.Label label26;
        private System.Windows.Forms.Button btnElectricalContact;
        internal System.Windows.Forms.TextBox textBox82;
        internal System.Windows.Forms.Label label95;
        internal System.Windows.Forms.TextBox textBox83;
        private System.Windows.Forms.MaskedTextBox maskedTextBox5;
        internal System.Windows.Forms.Label label29;
        internal System.Windows.Forms.Label label28;
        private System.Windows.Forms.MaskedTextBox maskedTextBox4;
        internal System.Windows.Forms.Label label27;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.MaskedTextBox maskedTextBox2;
        internal System.Windows.Forms.Label label11;
        private System.Windows.Forms.MaskedTextBox maskedTextBox1;
        internal System.Windows.Forms.Label label10;
        internal System.Windows.Forms.TextBox textBox3;
        internal System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnApplicantContact;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.ComboBox comboBox2;
        internal System.Windows.Forms.TextBox textBox12;
        internal System.Windows.Forms.Label label8;
        internal System.Windows.Forms.TextBox textBox9;
        internal System.Windows.Forms.Label label7;
        internal System.Windows.Forms.TextBox textBox7;
        internal System.Windows.Forms.Label label6;
        internal System.Windows.Forms.TextBox textBox6;
        internal System.Windows.Forms.Label label5;
        internal System.Windows.Forms.TextBox textBox5;
        internal System.Windows.Forms.Label label4;
        internal System.Windows.Forms.TextBox textBox4;
        internal System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnPropertyContact;
        internal System.Windows.Forms.TextBox textBox10;
        internal System.Windows.Forms.Label label9;
        internal System.Windows.Forms.Label Title;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.MaskedTextBox maskedTextBox9;
        internal System.Windows.Forms.Label label37;
        private System.Windows.Forms.Button btnIrrigationContact;
        internal System.Windows.Forms.TextBox textBox26;
        internal System.Windows.Forms.Label label38;
        internal System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.MaskedTextBox maskedTextBox8;
        internal System.Windows.Forms.Label label35;
        private System.Windows.Forms.Button btngasContact;
        internal System.Windows.Forms.TextBox textBox24;
        internal System.Windows.Forms.Label label36;
        internal System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.MaskedTextBox maskedTextBox7;
        internal System.Windows.Forms.Label label33;
        private System.Windows.Forms.Button btnMechanicalContact;
        internal System.Windows.Forms.TextBox textBox22;
        internal System.Windows.Forms.Label label34;
        internal System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.MaskedTextBox maskedTextBox6;
        internal System.Windows.Forms.Label label31;
        private System.Windows.Forms.Button btnPlumbingContact;
        internal System.Windows.Forms.TextBox textBox20;
        internal System.Windows.Forms.Label label32;
        internal System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.Button btnContractorContact;
        internal System.Windows.Forms.TextBox textBox19;
        internal System.Windows.Forms.Label label30;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.MaskedTextBox maskedTextBox10;
        internal System.Windows.Forms.Label label1;
        private System.Windows.Forms.MaskedTextBox maskedTextBox11;
        internal System.Windows.Forms.Label label12;
        internal System.Windows.Forms.TextBox textBox1;
        internal System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btnOwnerContact;
        private System.Windows.Forms.GroupBox groupBox6;
        internal System.Windows.Forms.TextBox textBox13;
        internal System.Windows.Forms.Label label16;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.GroupBox groupBox8;
        internal System.Windows.Forms.TextBox textBox43;
        internal System.Windows.Forms.Label label56;
        internal System.Windows.Forms.TextBox textBox44;
        internal System.Windows.Forms.Label label57;
        internal System.Windows.Forms.TextBox textBox45;
        internal System.Windows.Forms.Label label58;
        internal System.Windows.Forms.TextBox textBox46;
        internal System.Windows.Forms.Label label59;
        internal System.Windows.Forms.TextBox textBox47;
        internal System.Windows.Forms.Label label60;
        internal System.Windows.Forms.TextBox textBox48;
        internal System.Windows.Forms.Label label61;
        internal System.Windows.Forms.TextBox textBox49;
        internal System.Windows.Forms.Label label62;
        internal System.Windows.Forms.TextBox textBox50;
        internal System.Windows.Forms.Label label63;
        internal System.Windows.Forms.TextBox textBox51;
        internal System.Windows.Forms.Label label64;
        internal System.Windows.Forms.TextBox textBox53;
        internal System.Windows.Forms.Label label72;
        internal System.Windows.Forms.TextBox textBox54;
        internal System.Windows.Forms.Label label73;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.RadioButton radioButton12;
        internal System.Windows.Forms.TextBox textBox55;
        internal System.Windows.Forms.Label label78;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.ComboBox comboBox5;
        internal System.Windows.Forms.TextBox textBox14;
        internal System.Windows.Forms.Label label15;
        internal System.Windows.Forms.TextBox textBox18;
        internal System.Windows.Forms.Label label39;
        private System.Windows.Forms.GroupBox groupBox15;
        internal System.Windows.Forms.TextBox textBox57;
        internal System.Windows.Forms.Label label109;
        internal System.Windows.Forms.TextBox textBox58;
        internal System.Windows.Forms.Label label110;
        internal System.Windows.Forms.TextBox textBox60;
        internal System.Windows.Forms.Label label112;
        internal System.Windows.Forms.TextBox textBox61;
        internal System.Windows.Forms.Label label113;
        internal System.Windows.Forms.TextBox textBox62;
        internal System.Windows.Forms.Label label114;
        internal System.Windows.Forms.TextBox textBox63;
        internal System.Windows.Forms.Label label115;
        private System.Windows.Forms.GroupBox groupBox19;
        internal System.Windows.Forms.Label label24;
        private System.Windows.Forms.DateTimePicker dateTimePicker3;
        internal System.Windows.Forms.Label label23;
        internal System.Windows.Forms.Label label22;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        internal System.Windows.Forms.Label label21;
        private System.Windows.Forms.ComboBox comboBox1;
        internal System.Windows.Forms.TextBox textBox8;
        internal System.Windows.Forms.Label label20;
        internal System.Windows.Forms.TextBox textBox2;
        internal System.Windows.Forms.Label label19;
        private System.Windows.Forms.GroupBox groupBox18;
        internal System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.Button btnFees;

    }
}