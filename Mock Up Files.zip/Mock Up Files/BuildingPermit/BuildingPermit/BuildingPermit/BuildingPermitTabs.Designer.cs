﻿namespace BuildingPermit
{
    partial class BuildingPermitTabs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Contractor = new System.Windows.Forms.TabPage();
            this.Contractors = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label87 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.textBox69 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.TextBox7 = new System.Windows.Forms.TextBox();
            this.TextBox6 = new System.Windows.Forms.TextBox();
            this.TextBox5 = new System.Windows.Forms.TextBox();
            this.TextBox4 = new System.Windows.Forms.TextBox();
            this.TextBox3 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.TextBox1 = new System.Windows.Forms.TextBox();
            this.label84 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.maskedTextBox2 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox1 = new System.Windows.Forms.MaskedTextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.Label8 = new System.Windows.Forms.Label();
            this.Label7 = new System.Windows.Forms.Label();
            this.Label6 = new System.Windows.Forms.Label();
            this.Label5 = new System.Windows.Forms.Label();
            this.Label4 = new System.Windows.Forms.Label();
            this.Label3 = new System.Windows.Forms.Label();
            this.Label2 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.Title = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.textBox66 = new System.Windows.Forms.TextBox();
            this.textBox67 = new System.Windows.Forms.TextBox();
            this.textBox68 = new System.Windows.Forms.TextBox();
            this.textBox63 = new System.Windows.Forms.TextBox();
            this.textBox64 = new System.Windows.Forms.TextBox();
            this.textBox65 = new System.Windows.Forms.TextBox();
            this.textBox60 = new System.Windows.Forms.TextBox();
            this.textBox61 = new System.Windows.Forms.TextBox();
            this.textBox62 = new System.Windows.Forms.TextBox();
            this.textBox57 = new System.Windows.Forms.TextBox();
            this.textBox58 = new System.Windows.Forms.TextBox();
            this.textBox59 = new System.Windows.Forms.TextBox();
            this.textBox56 = new System.Windows.Forms.TextBox();
            this.textBox54 = new System.Windows.Forms.TextBox();
            this.textBox55 = new System.Windows.Forms.TextBox();
            this.textBox53 = new System.Windows.Forms.TextBox();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.textBox46 = new System.Windows.Forms.TextBox();
            this.textBox47 = new System.Windows.Forms.TextBox();
            this.textBox48 = new System.Windows.Forms.TextBox();
            this.textBox49 = new System.Windows.Forms.TextBox();
            this.textBox50 = new System.Windows.Forms.TextBox();
            this.textBox51 = new System.Windows.Forms.TextBox();
            this.textBox52 = new System.Windows.Forms.TextBox();
            this.label79 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.checkBox10 = new System.Windows.Forms.CheckBox();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.textBox70 = new System.Windows.Forms.TextBox();
            this.textBox71 = new System.Windows.Forms.TextBox();
            this.textBox72 = new System.Windows.Forms.TextBox();
            this.textBox73 = new System.Windows.Forms.TextBox();
            this.textBox74 = new System.Windows.Forms.TextBox();
            this.textBox75 = new System.Windows.Forms.TextBox();
            this.textBox76 = new System.Windows.Forms.TextBox();
            this.textBox77 = new System.Windows.Forms.TextBox();
            this.textBox78 = new System.Windows.Forms.TextBox();
            this.textBox79 = new System.Windows.Forms.TextBox();
            this.textBox80 = new System.Windows.Forms.TextBox();
            this.textBox81 = new System.Windows.Forms.TextBox();
            this.textBox82 = new System.Windows.Forms.TextBox();
            this.textBox83 = new System.Windows.Forms.TextBox();
            this.label88 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label97 = new System.Windows.Forms.Label();
            this.label98 = new System.Windows.Forms.Label();
            this.label99 = new System.Windows.Forms.Label();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.label100 = new System.Windows.Forms.Label();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.label101 = new System.Windows.Forms.Label();
            this.label102 = new System.Windows.Forms.Label();
            this.label103 = new System.Windows.Forms.Label();
            this.label104 = new System.Windows.Forms.Label();
            this.label105 = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.label106 = new System.Windows.Forms.Label();
            this.radioButton11 = new System.Windows.Forms.RadioButton();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.label107 = new System.Windows.Forms.Label();
            this.radioButton12 = new System.Windows.Forms.RadioButton();
            this.label108 = new System.Windows.Forms.Label();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.radioButton13 = new System.Windows.Forms.RadioButton();
            this.radioButton14 = new System.Windows.Forms.RadioButton();
            this.label109 = new System.Windows.Forms.Label();
            this.label110 = new System.Windows.Forms.Label();
            this.label111 = new System.Windows.Forms.Label();
            this.label112 = new System.Windows.Forms.Label();
            this.label113 = new System.Windows.Forms.Label();
            this.textBox84 = new System.Windows.Forms.TextBox();
            this.textBox85 = new System.Windows.Forms.TextBox();
            this.textBox86 = new System.Windows.Forms.TextBox();
            this.textBox87 = new System.Windows.Forms.TextBox();
            this.textBox88 = new System.Windows.Forms.TextBox();
            this.textBox89 = new System.Windows.Forms.TextBox();
            this.textBox90 = new System.Windows.Forms.TextBox();
            this.textBox91 = new System.Windows.Forms.TextBox();
            this.textBox92 = new System.Windows.Forms.TextBox();
            this.textBox93 = new System.Windows.Forms.TextBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.label114 = new System.Windows.Forms.Label();
            this.label115 = new System.Windows.Forms.Label();
            this.label116 = new System.Windows.Forms.Label();
            this.label117 = new System.Windows.Forms.Label();
            this.label118 = new System.Windows.Forms.Label();
            this.label119 = new System.Windows.Forms.Label();
            this.label120 = new System.Windows.Forms.Label();
            this.label121 = new System.Windows.Forms.Label();
            this.label122 = new System.Windows.Forms.Label();
            this.label123 = new System.Windows.Forms.Label();
            this.label124 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label82 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.dateTimePicker3 = new System.Windows.Forms.DateTimePicker();
            this.label24 = new System.Windows.Forms.Label();
            this.Contractor.SuspendLayout();
            this.Contractors.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.SuspendLayout();
            // 
            // Contractor
            // 
            this.Contractor.Controls.Add(this.button4);
            this.Contractor.Controls.Add(this.button3);
            this.Contractor.Controls.Add(this.textBox66);
            this.Contractor.Controls.Add(this.textBox67);
            this.Contractor.Controls.Add(this.textBox68);
            this.Contractor.Controls.Add(this.textBox63);
            this.Contractor.Controls.Add(this.textBox64);
            this.Contractor.Controls.Add(this.textBox65);
            this.Contractor.Controls.Add(this.textBox60);
            this.Contractor.Controls.Add(this.textBox61);
            this.Contractor.Controls.Add(this.textBox62);
            this.Contractor.Controls.Add(this.textBox57);
            this.Contractor.Controls.Add(this.textBox58);
            this.Contractor.Controls.Add(this.textBox59);
            this.Contractor.Controls.Add(this.textBox56);
            this.Contractor.Controls.Add(this.textBox54);
            this.Contractor.Controls.Add(this.textBox55);
            this.Contractor.Controls.Add(this.textBox53);
            this.Contractor.Controls.Add(this.textBox43);
            this.Contractor.Controls.Add(this.textBox44);
            this.Contractor.Controls.Add(this.textBox45);
            this.Contractor.Controls.Add(this.textBox46);
            this.Contractor.Controls.Add(this.textBox47);
            this.Contractor.Controls.Add(this.textBox48);
            this.Contractor.Controls.Add(this.textBox49);
            this.Contractor.Controls.Add(this.textBox50);
            this.Contractor.Controls.Add(this.textBox51);
            this.Contractor.Controls.Add(this.textBox52);
            this.Contractor.Controls.Add(this.label79);
            this.Contractor.Controls.Add(this.label80);
            this.Contractor.Controls.Add(this.label81);
            this.Contractor.Controls.Add(this.label76);
            this.Contractor.Controls.Add(this.label77);
            this.Contractor.Controls.Add(this.label78);
            this.Contractor.Controls.Add(this.label73);
            this.Contractor.Controls.Add(this.label74);
            this.Contractor.Controls.Add(this.label75);
            this.Contractor.Controls.Add(this.label70);
            this.Contractor.Controls.Add(this.label71);
            this.Contractor.Controls.Add(this.label72);
            this.Contractor.Controls.Add(this.label69);
            this.Contractor.Controls.Add(this.label67);
            this.Contractor.Controls.Add(this.label68);
            this.Contractor.Controls.Add(this.label56);
            this.Contractor.Controls.Add(this.checkBox10);
            this.Contractor.Controls.Add(this.label57);
            this.Contractor.Controls.Add(this.label58);
            this.Contractor.Controls.Add(this.label59);
            this.Contractor.Controls.Add(this.label60);
            this.Contractor.Controls.Add(this.label61);
            this.Contractor.Controls.Add(this.label62);
            this.Contractor.Controls.Add(this.label63);
            this.Contractor.Controls.Add(this.label64);
            this.Contractor.Controls.Add(this.label65);
            this.Contractor.Controls.Add(this.label66);
            this.Contractor.Location = new System.Drawing.Point(4, 22);
            this.Contractor.Name = "Contractor";
            this.Contractor.Padding = new System.Windows.Forms.Padding(3);
            this.Contractor.Size = new System.Drawing.Size(715, 467);
            this.Contractor.TabIndex = 3;
            this.Contractor.Text = "Contractor";
            this.Contractor.UseVisualStyleBackColor = true;
            // 
            // Contractors
            // 
            this.Contractors.Controls.Add(this.button5);
            this.Contractors.Controls.Add(this.textBox70);
            this.Contractors.Controls.Add(this.textBox71);
            this.Contractors.Controls.Add(this.textBox72);
            this.Contractors.Controls.Add(this.textBox73);
            this.Contractors.Controls.Add(this.textBox74);
            this.Contractors.Controls.Add(this.textBox75);
            this.Contractors.Controls.Add(this.textBox76);
            this.Contractors.Controls.Add(this.textBox77);
            this.Contractors.Controls.Add(this.textBox78);
            this.Contractors.Controls.Add(this.textBox79);
            this.Contractors.Controls.Add(this.textBox80);
            this.Contractors.Controls.Add(this.textBox81);
            this.Contractors.Controls.Add(this.textBox82);
            this.Contractors.Controls.Add(this.textBox83);
            this.Contractors.Controls.Add(this.label88);
            this.Contractors.Controls.Add(this.label89);
            this.Contractors.Controls.Add(this.label90);
            this.Contractors.Controls.Add(this.label91);
            this.Contractors.Controls.Add(this.label92);
            this.Contractors.Controls.Add(this.label93);
            this.Contractors.Controls.Add(this.label94);
            this.Contractors.Controls.Add(this.label95);
            this.Contractors.Controls.Add(this.label96);
            this.Contractors.Controls.Add(this.groupBox6);
            this.Contractors.Controls.Add(this.groupBox7);
            this.Contractors.Controls.Add(this.label101);
            this.Contractors.Controls.Add(this.label102);
            this.Contractors.Controls.Add(this.label103);
            this.Contractors.Controls.Add(this.label104);
            this.Contractors.Controls.Add(this.label105);
            this.Contractors.Controls.Add(this.groupBox8);
            this.Contractors.Controls.Add(this.groupBox9);
            this.Contractors.Controls.Add(this.label108);
            this.Contractors.Controls.Add(this.groupBox10);
            this.Contractors.Controls.Add(this.label109);
            this.Contractors.Controls.Add(this.label110);
            this.Contractors.Controls.Add(this.label111);
            this.Contractors.Controls.Add(this.label112);
            this.Contractors.Controls.Add(this.label113);
            this.Contractors.Location = new System.Drawing.Point(4, 22);
            this.Contractors.Name = "Contractors";
            this.Contractors.Padding = new System.Windows.Forms.Padding(3);
            this.Contractors.Size = new System.Drawing.Size(715, 467);
            this.Contractors.TabIndex = 2;
            this.Contractors.Text = "Utilities";
            this.Contractors.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.textBox84);
            this.tabPage2.Controls.Add(this.textBox85);
            this.tabPage2.Controls.Add(this.textBox86);
            this.tabPage2.Controls.Add(this.textBox87);
            this.tabPage2.Controls.Add(this.textBox88);
            this.tabPage2.Controls.Add(this.textBox89);
            this.tabPage2.Controls.Add(this.textBox90);
            this.tabPage2.Controls.Add(this.textBox91);
            this.tabPage2.Controls.Add(this.textBox92);
            this.tabPage2.Controls.Add(this.textBox93);
            this.tabPage2.Controls.Add(this.checkBox1);
            this.tabPage2.Controls.Add(this.label114);
            this.tabPage2.Controls.Add(this.label115);
            this.tabPage2.Controls.Add(this.label116);
            this.tabPage2.Controls.Add(this.label117);
            this.tabPage2.Controls.Add(this.label118);
            this.tabPage2.Controls.Add(this.label119);
            this.tabPage2.Controls.Add(this.label120);
            this.tabPage2.Controls.Add(this.label121);
            this.tabPage2.Controls.Add(this.label122);
            this.tabPage2.Controls.Add(this.label123);
            this.tabPage2.Controls.Add(this.label124);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(715, 467);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Continued";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dateTimePicker3);
            this.tabPage1.Controls.Add(this.label24);
            this.tabPage1.Controls.Add(this.textBox23);
            this.tabPage1.Controls.Add(this.label23);
            this.tabPage1.Controls.Add(this.label83);
            this.tabPage1.Controls.Add(this.comboBox2);
            this.tabPage1.Controls.Add(this.label82);
            this.tabPage1.Controls.Add(this.comboBox1);
            this.tabPage1.Controls.Add(this.textBox9);
            this.tabPage1.Controls.Add(this.textBox22);
            this.tabPage1.Controls.Add(this.label21);
            this.tabPage1.Controls.Add(this.label22);
            this.tabPage1.Controls.Add(this.textBox2);
            this.tabPage1.Controls.Add(this.textBox8);
            this.tabPage1.Controls.Add(this.label19);
            this.tabPage1.Controls.Add(this.label20);
            this.tabPage1.Controls.Add(this.dateTimePicker2);
            this.tabPage1.Controls.Add(this.dateTimePicker1);
            this.tabPage1.Controls.Add(this.label87);
            this.tabPage1.Controls.Add(this.label86);
            this.tabPage1.Controls.Add(this.label85);
            this.tabPage1.Controls.Add(this.comboBox3);
            this.tabPage1.Controls.Add(this.textBox69);
            this.tabPage1.Controls.Add(this.textBox12);
            this.tabPage1.Controls.Add(this.textBox13);
            this.tabPage1.Controls.Add(this.textBox14);
            this.tabPage1.Controls.Add(this.textBox15);
            this.tabPage1.Controls.Add(this.textBox16);
            this.tabPage1.Controls.Add(this.textBox17);
            this.tabPage1.Controls.Add(this.textBox18);
            this.tabPage1.Controls.Add(this.textBox19);
            this.tabPage1.Controls.Add(this.textBox20);
            this.tabPage1.Controls.Add(this.textBox21);
            this.tabPage1.Controls.Add(this.TextBox7);
            this.tabPage1.Controls.Add(this.TextBox6);
            this.tabPage1.Controls.Add(this.TextBox5);
            this.tabPage1.Controls.Add(this.TextBox4);
            this.tabPage1.Controls.Add(this.TextBox3);
            this.tabPage1.Controls.Add(this.textBox11);
            this.tabPage1.Controls.Add(this.textBox10);
            this.tabPage1.Controls.Add(this.TextBox1);
            this.tabPage1.Controls.Add(this.label84);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.maskedTextBox2);
            this.tabPage1.Controls.Add(this.maskedTextBox1);
            this.tabPage1.Controls.Add(this.label11);
            this.tabPage1.Controls.Add(this.label12);
            this.tabPage1.Controls.Add(this.label13);
            this.tabPage1.Controls.Add(this.label14);
            this.tabPage1.Controls.Add(this.label15);
            this.tabPage1.Controls.Add(this.label16);
            this.tabPage1.Controls.Add(this.label17);
            this.tabPage1.Controls.Add(this.label18);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Controls.Add(this.Label8);
            this.tabPage1.Controls.Add(this.Label7);
            this.tabPage1.Controls.Add(this.Label6);
            this.tabPage1.Controls.Add(this.Label5);
            this.tabPage1.Controls.Add(this.Label4);
            this.tabPage1.Controls.Add(this.Label3);
            this.tabPage1.Controls.Add(this.Label2);
            this.tabPage1.Controls.Add(this.Label1);
            this.tabPage1.Controls.Add(this.Title);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(715, 467);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Main";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(596, 114);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(100, 20);
            this.dateTimePicker2.TabIndex = 171;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(596, 88);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(100, 20);
            this.dateTimePicker1.TabIndex = 170;
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Location = new System.Drawing.Point(535, 117);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(52, 13);
            this.label87.TabIndex = 165;
            this.label87.Text = "End Date";
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Location = new System.Drawing.Point(532, 88);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(55, 13);
            this.label86.TabIndex = 163;
            this.label86.Text = "Start Date";
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Location = new System.Drawing.Point(550, 61);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(37, 13);
            this.label85.TabIndex = 162;
            this.label85.Text = "Status";
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(596, 61);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(100, 21);
            this.comboBox3.TabIndex = 161;
            // 
            // textBox69
            // 
            this.textBox69.Location = new System.Drawing.Point(596, 8);
            this.textBox69.Name = "textBox69";
            this.textBox69.Size = new System.Drawing.Size(100, 20);
            this.textBox69.TabIndex = 160;
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(282, 435);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(100, 20);
            this.textBox12.TabIndex = 141;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(88, 438);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(100, 20);
            this.textBox13.TabIndex = 142;
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(531, 403);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(59, 20);
            this.textBox14.TabIndex = 148;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(442, 402);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(43, 20);
            this.textBox15.TabIndex = 150;
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(276, 402);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(100, 20);
            this.textBox16.TabIndex = 143;
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(129, 405);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(100, 20);
            this.textBox17.TabIndex = 149;
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(456, 367);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(100, 20);
            this.textBox18.TabIndex = 147;
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(231, 367);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(37, 20);
            this.textBox19.TabIndex = 146;
            this.textBox19.Text = "MI";
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(274, 367);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(89, 20);
            this.textBox20.TabIndex = 145;
            this.textBox20.Text = "Last Name";
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(130, 367);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(89, 20);
            this.textBox21.TabIndex = 144;
            this.textBox21.Text = "First Name";
            // 
            // TextBox7
            // 
            this.TextBox7.Location = new System.Drawing.Point(88, 307);
            this.TextBox7.Name = "TextBox7";
            this.TextBox7.Size = new System.Drawing.Size(100, 20);
            this.TextBox7.TabIndex = 124;
            // 
            // TextBox6
            // 
            this.TextBox6.Location = new System.Drawing.Point(531, 262);
            this.TextBox6.Name = "TextBox6";
            this.TextBox6.Size = new System.Drawing.Size(59, 20);
            this.TextBox6.TabIndex = 129;
            // 
            // TextBox5
            // 
            this.TextBox5.Location = new System.Drawing.Point(442, 261);
            this.TextBox5.Name = "TextBox5";
            this.TextBox5.Size = new System.Drawing.Size(43, 20);
            this.TextBox5.TabIndex = 131;
            // 
            // TextBox4
            // 
            this.TextBox4.Location = new System.Drawing.Point(276, 261);
            this.TextBox4.Name = "TextBox4";
            this.TextBox4.Size = new System.Drawing.Size(100, 20);
            this.TextBox4.TabIndex = 125;
            // 
            // TextBox3
            // 
            this.TextBox3.Location = new System.Drawing.Point(129, 264);
            this.TextBox3.Name = "TextBox3";
            this.TextBox3.Size = new System.Drawing.Size(100, 20);
            this.TextBox3.TabIndex = 130;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(200, 226);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(37, 20);
            this.textBox11.TabIndex = 127;
            this.textBox11.Text = "MI";
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(243, 226);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(89, 20);
            this.textBox10.TabIndex = 128;
            this.textBox10.Text = "Last Name";
            // 
            // TextBox1
            // 
            this.TextBox1.Location = new System.Drawing.Point(99, 226);
            this.TextBox1.Name = "TextBox1";
            this.TextBox1.Size = new System.Drawing.Size(89, 20);
            this.TextBox1.TabIndex = 126;
            this.TextBox1.Text = "First Name";
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Location = new System.Drawing.Point(519, 11);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(69, 13);
            this.label84.TabIndex = 159;
            this.label84.Text = "Application #";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(621, 422);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 154;
            this.button1.Text = "Next";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(43, 192);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(163, 13);
            this.label9.TabIndex = 153;
            this.label9.Text = "Project Address Information";
            // 
            // maskedTextBox2
            // 
            this.maskedTextBox2.Location = new System.Drawing.Point(282, 304);
            this.maskedTextBox2.Mask = "(999) 000-0000";
            this.maskedTextBox2.Name = "maskedTextBox2";
            this.maskedTextBox2.Size = new System.Drawing.Size(100, 20);
            this.maskedTextBox2.TabIndex = 152;
            // 
            // maskedTextBox1
            // 
            this.maskedTextBox1.Location = new System.Drawing.Point(433, 229);
            this.maskedTextBox1.Mask = "(999) 000-0000";
            this.maskedTextBox1.Name = "maskedTextBox1";
            this.maskedTextBox1.Size = new System.Drawing.Size(100, 20);
            this.maskedTextBox1.TabIndex = 151;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(222, 438);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(54, 13);
            this.label11.TabIndex = 138;
            this.label11.Text = "Cellphone";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(42, 438);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(32, 13);
            this.label12.TabIndex = 136;
            this.label12.Text = "Email";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(503, 406);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(22, 13);
            this.label13.TabIndex = 139;
            this.label13.Text = "Zip";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(404, 406);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(32, 13);
            this.label14.TabIndex = 137;
            this.label14.Text = "State";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(246, 405);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(24, 13);
            this.label15.TabIndex = 140;
            this.label15.Text = "City";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(42, 405);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(81, 13);
            this.label16.TabIndex = 133;
            this.label16.Text = "Mailing Address";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(402, 370);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(48, 13);
            this.label17.TabIndex = 134;
            this.label17.Text = "Phone #";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(42, 370);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(80, 13);
            this.label18.TabIndex = 135;
            this.label18.Text = "Property Owner";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(42, 337);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(595, 13);
            this.label10.TabIndex = 132;
            this.label10.Text = "---------------------------------------------------------------------------------" +
                "--------------------------------------------------------------------------------" +
                "-----------------------------------";
            // 
            // Label8
            // 
            this.Label8.AutoSize = true;
            this.Label8.Location = new System.Drawing.Point(222, 307);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(54, 13);
            this.Label8.TabIndex = 121;
            this.Label8.Text = "Cellphone";
            // 
            // Label7
            // 
            this.Label7.AutoSize = true;
            this.Label7.Location = new System.Drawing.Point(42, 307);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(32, 13);
            this.Label7.TabIndex = 119;
            this.Label7.Text = "Email";
            // 
            // Label6
            // 
            this.Label6.AutoSize = true;
            this.Label6.Location = new System.Drawing.Point(503, 265);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(22, 13);
            this.Label6.TabIndex = 122;
            this.Label6.Text = "Zip";
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Location = new System.Drawing.Point(404, 265);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(32, 13);
            this.Label5.TabIndex = 120;
            this.Label5.Text = "State";
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Location = new System.Drawing.Point(246, 264);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(24, 13);
            this.Label4.TabIndex = 123;
            this.Label4.Text = "City";
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Location = new System.Drawing.Point(42, 264);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(81, 13);
            this.Label3.TabIndex = 116;
            this.Label3.Text = "Mailing Address";
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Location = new System.Drawing.Point(371, 229);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(48, 13);
            this.Label2.TabIndex = 117;
            this.Label2.Text = "Phone #";
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Location = new System.Drawing.Point(42, 229);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(51, 13);
            this.Label1.TabIndex = 118;
            this.Label1.Text = "Applicant";
            // 
            // Title
            // 
            this.Title.AutoSize = true;
            this.Title.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Title.Location = new System.Drawing.Point(7, 8);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(376, 26);
            this.Title.TabIndex = 106;
            this.Title.Text = "Town Of Aberdeen Permit Application";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.Contractors);
            this.tabControl1.Controls.Add(this.Contractor);
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(723, 493);
            this.tabControl1.TabIndex = 0;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(26, 40);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(124, 23);
            this.button4.TabIndex = 187;
            this.button4.Text = "Add Contractor";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(581, 403);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 186;
            this.button3.Text = "Submit";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // textBox66
            // 
            this.textBox66.Location = new System.Drawing.Point(613, 248);
            this.textBox66.Name = "textBox66";
            this.textBox66.Size = new System.Drawing.Size(76, 20);
            this.textBox66.TabIndex = 185;
            // 
            // textBox67
            // 
            this.textBox67.Location = new System.Drawing.Point(414, 250);
            this.textBox67.Name = "textBox67";
            this.textBox67.Size = new System.Drawing.Size(89, 20);
            this.textBox67.TabIndex = 183;
            // 
            // textBox68
            // 
            this.textBox68.Location = new System.Drawing.Point(120, 251);
            this.textBox68.Name = "textBox68";
            this.textBox68.Size = new System.Drawing.Size(202, 20);
            this.textBox68.TabIndex = 182;
            // 
            // textBox63
            // 
            this.textBox63.Location = new System.Drawing.Point(613, 222);
            this.textBox63.Name = "textBox63";
            this.textBox63.Size = new System.Drawing.Size(76, 20);
            this.textBox63.TabIndex = 179;
            // 
            // textBox64
            // 
            this.textBox64.Location = new System.Drawing.Point(414, 224);
            this.textBox64.Name = "textBox64";
            this.textBox64.Size = new System.Drawing.Size(89, 20);
            this.textBox64.TabIndex = 177;
            // 
            // textBox65
            // 
            this.textBox65.Location = new System.Drawing.Point(120, 225);
            this.textBox65.Name = "textBox65";
            this.textBox65.Size = new System.Drawing.Size(202, 20);
            this.textBox65.TabIndex = 176;
            // 
            // textBox60
            // 
            this.textBox60.Location = new System.Drawing.Point(613, 196);
            this.textBox60.Name = "textBox60";
            this.textBox60.Size = new System.Drawing.Size(76, 20);
            this.textBox60.TabIndex = 173;
            // 
            // textBox61
            // 
            this.textBox61.Location = new System.Drawing.Point(414, 198);
            this.textBox61.Name = "textBox61";
            this.textBox61.Size = new System.Drawing.Size(89, 20);
            this.textBox61.TabIndex = 171;
            // 
            // textBox62
            // 
            this.textBox62.Location = new System.Drawing.Point(120, 199);
            this.textBox62.Name = "textBox62";
            this.textBox62.Size = new System.Drawing.Size(202, 20);
            this.textBox62.TabIndex = 170;
            // 
            // textBox57
            // 
            this.textBox57.Location = new System.Drawing.Point(613, 170);
            this.textBox57.Name = "textBox57";
            this.textBox57.Size = new System.Drawing.Size(76, 20);
            this.textBox57.TabIndex = 167;
            // 
            // textBox58
            // 
            this.textBox58.Location = new System.Drawing.Point(414, 172);
            this.textBox58.Name = "textBox58";
            this.textBox58.Size = new System.Drawing.Size(89, 20);
            this.textBox58.TabIndex = 165;
            // 
            // textBox59
            // 
            this.textBox59.Location = new System.Drawing.Point(120, 173);
            this.textBox59.Name = "textBox59";
            this.textBox59.Size = new System.Drawing.Size(202, 20);
            this.textBox59.TabIndex = 164;
            // 
            // textBox56
            // 
            this.textBox56.Location = new System.Drawing.Point(613, 142);
            this.textBox56.Name = "textBox56";
            this.textBox56.Size = new System.Drawing.Size(76, 20);
            this.textBox56.TabIndex = 161;
            // 
            // textBox54
            // 
            this.textBox54.Location = new System.Drawing.Point(414, 144);
            this.textBox54.Name = "textBox54";
            this.textBox54.Size = new System.Drawing.Size(89, 20);
            this.textBox54.TabIndex = 159;
            // 
            // textBox55
            // 
            this.textBox55.Location = new System.Drawing.Point(120, 145);
            this.textBox55.Name = "textBox55";
            this.textBox55.Size = new System.Drawing.Size(202, 20);
            this.textBox55.TabIndex = 158;
            // 
            // textBox53
            // 
            this.textBox53.Location = new System.Drawing.Point(577, 111);
            this.textBox53.Name = "textBox53";
            this.textBox53.Size = new System.Drawing.Size(100, 20);
            this.textBox53.TabIndex = 155;
            // 
            // textBox43
            // 
            this.textBox43.Location = new System.Drawing.Point(621, 317);
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new System.Drawing.Size(60, 20);
            this.textBox43.TabIndex = 149;
            // 
            // textBox44
            // 
            this.textBox44.Location = new System.Drawing.Point(472, 317);
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new System.Drawing.Size(100, 20);
            this.textBox44.TabIndex = 148;
            // 
            // textBox45
            // 
            this.textBox45.Location = new System.Drawing.Point(337, 352);
            this.textBox45.Name = "textBox45";
            this.textBox45.Size = new System.Drawing.Size(100, 20);
            this.textBox45.TabIndex = 147;
            // 
            // textBox46
            // 
            this.textBox46.Location = new System.Drawing.Point(302, 317);
            this.textBox46.Name = "textBox46";
            this.textBox46.Size = new System.Drawing.Size(100, 20);
            this.textBox46.TabIndex = 152;
            // 
            // textBox47
            // 
            this.textBox47.Location = new System.Drawing.Point(114, 317);
            this.textBox47.Name = "textBox47";
            this.textBox47.Size = new System.Drawing.Size(100, 20);
            this.textBox47.TabIndex = 151;
            // 
            // textBox48
            // 
            this.textBox48.Location = new System.Drawing.Point(489, 110);
            this.textBox48.Name = "textBox48";
            this.textBox48.Size = new System.Drawing.Size(36, 20);
            this.textBox48.TabIndex = 150;
            // 
            // textBox49
            // 
            this.textBox49.Location = new System.Drawing.Point(327, 110);
            this.textBox49.Name = "textBox49";
            this.textBox49.Size = new System.Drawing.Size(100, 20);
            this.textBox49.TabIndex = 146;
            // 
            // textBox50
            // 
            this.textBox50.Location = new System.Drawing.Point(75, 111);
            this.textBox50.Name = "textBox50";
            this.textBox50.Size = new System.Drawing.Size(217, 20);
            this.textBox50.TabIndex = 145;
            // 
            // textBox51
            // 
            this.textBox51.Location = new System.Drawing.Point(445, 79);
            this.textBox51.Name = "textBox51";
            this.textBox51.Size = new System.Drawing.Size(166, 20);
            this.textBox51.TabIndex = 144;
            // 
            // textBox52
            // 
            this.textBox52.Location = new System.Drawing.Point(135, 79);
            this.textBox52.Name = "textBox52";
            this.textBox52.Size = new System.Drawing.Size(228, 20);
            this.textBox52.TabIndex = 143;
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Location = new System.Drawing.Point(519, 252);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(88, 13);
            this.label79.TabIndex = 184;
            this.label79.Text = "Aberdeen B.L. #:";
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Location = new System.Drawing.Point(352, 254);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(54, 13);
            this.label80.TabIndex = 181;
            this.label80.Text = "License#:";
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Location = new System.Drawing.Point(27, 255);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(72, 13);
            this.label81.TabIndex = 180;
            this.label81.Text = "Irrigation Sub:";
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(519, 226);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(88, 13);
            this.label76.TabIndex = 178;
            this.label76.Text = "Aberdeen B.L. #:";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(352, 228);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(54, 13);
            this.label77.TabIndex = 175;
            this.label77.Text = "License#:";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Location = new System.Drawing.Point(27, 229);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(74, 13);
            this.label78.TabIndex = 174;
            this.label78.Text = "Gas Line Sub:";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(519, 200);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(88, 13);
            this.label73.TabIndex = 172;
            this.label73.Text = "Aberdeen B.L. #:";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Location = new System.Drawing.Point(352, 202);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(54, 13);
            this.label74.TabIndex = 169;
            this.label74.Text = "License#:";
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(27, 203);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(87, 13);
            this.label75.TabIndex = 168;
            this.label75.Text = "Mechanical Sub:";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(519, 174);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(88, 13);
            this.label70.TabIndex = 166;
            this.label70.Text = "Aberdeen B.L. #:";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(352, 176);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(54, 13);
            this.label71.TabIndex = 163;
            this.label71.Text = "License#:";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(27, 177);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(75, 13);
            this.label72.TabIndex = 162;
            this.label72.Text = "Plumbing Sub:";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(519, 146);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(88, 13);
            this.label69.TabIndex = 160;
            this.label69.Text = "Aberdeen B.L. #:";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(352, 148);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(54, 13);
            this.label67.TabIndex = 157;
            this.label67.Text = "License#:";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(27, 149);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(75, 13);
            this.label68.TabIndex = 156;
            this.label68.Text = "Electrical Sub:";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(545, 115);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(25, 13);
            this.label56.TabIndex = 154;
            this.label56.Text = "Zip:";
            // 
            // checkBox10
            // 
            this.checkBox10.AutoSize = true;
            this.checkBox10.Location = new System.Drawing.Point(41, 354);
            this.checkBox10.Name = "checkBox10";
            this.checkBox10.Size = new System.Drawing.Size(101, 17);
            this.checkBox10.TabIndex = 153;
            this.checkBox10.Text = "Install Insulation";
            this.checkBox10.UseVisualStyleBackColor = true;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(582, 321);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(33, 13);
            this.label57.TabIndex = 141;
            this.label57.Text = "Deck";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(415, 320);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(51, 13);
            this.label58.TabIndex = 135;
            this.label58.Text = "Porch SF";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(180, 354);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(151, 13);
            this.label59.TabIndex = 134;
            this.label59.Text = "Estimated Cost of Construction";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(242, 320);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(54, 13);
            this.label60.TabIndex = 138;
            this.label60.Text = "Basement";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(27, 317);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(58, 13);
            this.label61.TabIndex = 137;
            this.label61.Text = "Garage SF";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(448, 114);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(35, 13);
            this.label62.TabIndex = 136;
            this.label62.Text = "State:";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(295, 114);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(27, 13);
            this.label63.TabIndex = 133;
            this.label63.Text = "City:";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(25, 114);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(48, 13);
            this.label64.TabIndex = 142;
            this.label64.Text = "Address:";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(383, 83);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(54, 13);
            this.label65.TabIndex = 140;
            this.label65.Text = "License#:";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(27, 83);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(99, 13);
            this.label66.TabIndex = 139;
            this.label66.Text = "General Contractor:";
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(579, 429);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 217;
            this.button5.Text = "Next";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // textBox70
            // 
            this.textBox70.Location = new System.Drawing.Point(466, 321);
            this.textBox70.Name = "textBox70";
            this.textBox70.Size = new System.Drawing.Size(27, 20);
            this.textBox70.TabIndex = 216;
            // 
            // textBox71
            // 
            this.textBox71.Location = new System.Drawing.Point(312, 321);
            this.textBox71.Name = "textBox71";
            this.textBox71.Size = new System.Drawing.Size(27, 20);
            this.textBox71.TabIndex = 214;
            // 
            // textBox72
            // 
            this.textBox72.Location = new System.Drawing.Point(219, 321);
            this.textBox72.Name = "textBox72";
            this.textBox72.Size = new System.Drawing.Size(26, 20);
            this.textBox72.TabIndex = 213;
            // 
            // textBox73
            // 
            this.textBox73.Location = new System.Drawing.Point(106, 321);
            this.textBox73.Name = "textBox73";
            this.textBox73.Size = new System.Drawing.Size(27, 20);
            this.textBox73.TabIndex = 210;
            // 
            // textBox74
            // 
            this.textBox74.Location = new System.Drawing.Point(532, 297);
            this.textBox74.Name = "textBox74";
            this.textBox74.Size = new System.Drawing.Size(27, 20);
            this.textBox74.TabIndex = 208;
            // 
            // textBox75
            // 
            this.textBox75.Location = new System.Drawing.Point(386, 297);
            this.textBox75.Name = "textBox75";
            this.textBox75.Size = new System.Drawing.Size(27, 20);
            this.textBox75.TabIndex = 206;
            // 
            // textBox76
            // 
            this.textBox76.Location = new System.Drawing.Point(305, 297);
            this.textBox76.Name = "textBox76";
            this.textBox76.Size = new System.Drawing.Size(26, 20);
            this.textBox76.TabIndex = 205;
            // 
            // textBox77
            // 
            this.textBox77.Location = new System.Drawing.Point(212, 297);
            this.textBox77.Name = "textBox77";
            this.textBox77.Size = new System.Drawing.Size(27, 20);
            this.textBox77.TabIndex = 202;
            // 
            // textBox78
            // 
            this.textBox78.Location = new System.Drawing.Point(76, 297);
            this.textBox78.Name = "textBox78";
            this.textBox78.Size = new System.Drawing.Size(26, 20);
            this.textBox78.TabIndex = 201;
            // 
            // textBox79
            // 
            this.textBox79.Location = new System.Drawing.Point(444, 388);
            this.textBox79.Name = "textBox79";
            this.textBox79.Size = new System.Drawing.Size(100, 20);
            this.textBox79.TabIndex = 196;
            // 
            // textBox80
            // 
            this.textBox80.Location = new System.Drawing.Point(444, 274);
            this.textBox80.Name = "textBox80";
            this.textBox80.Size = new System.Drawing.Size(27, 20);
            this.textBox80.TabIndex = 192;
            // 
            // textBox81
            // 
            this.textBox81.Location = new System.Drawing.Point(211, 274);
            this.textBox81.Name = "textBox81";
            this.textBox81.Size = new System.Drawing.Size(26, 20);
            this.textBox81.TabIndex = 191;
            // 
            // textBox82
            // 
            this.textBox82.Location = new System.Drawing.Point(371, 189);
            this.textBox82.Name = "textBox82";
            this.textBox82.Size = new System.Drawing.Size(100, 20);
            this.textBox82.TabIndex = 182;
            // 
            // textBox83
            // 
            this.textBox83.Location = new System.Drawing.Point(130, 189);
            this.textBox83.Name = "textBox83";
            this.textBox83.Size = new System.Drawing.Size(100, 20);
            this.textBox83.TabIndex = 181;
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Location = new System.Drawing.Point(388, 324);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(74, 13);
            this.label88.TabIndex = 215;
            this.label88.Text = "Water Heater:";
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Location = new System.Drawing.Point(279, 324);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(29, 13);
            this.label89.TabIndex = 212;
            this.label89.Text = "Spa:";
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Location = new System.Drawing.Point(165, 324);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(49, 13);
            this.label90.TabIndex = 211;
            this.label90.Text = "Wet Bar:";
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Location = new System.Drawing.Point(39, 324);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(65, 13);
            this.label91.TabIndex = 209;
            this.label91.Text = "Dishwasher:";
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Location = new System.Drawing.Point(441, 300);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(90, 13);
            this.label92.TabIndex = 207;
            this.label92.Text = "Clothes Washers:";
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Location = new System.Drawing.Point(348, 300);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(34, 13);
            this.label93.TabIndex = 204;
            this.label93.Text = "Tubs:";
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Location = new System.Drawing.Point(249, 300);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(51, 13);
            this.label94.TabIndex = 203;
            this.label94.Text = "Showers:";
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Location = new System.Drawing.Point(130, 300);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(76, 13);
            this.label95.TabIndex = 200;
            this.label95.Text = "Water Closets:";
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Location = new System.Drawing.Point(38, 300);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(36, 13);
            this.label96.TabIndex = 199;
            this.label96.Text = "Sinks:";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.label97);
            this.groupBox6.Controls.Add(this.label98);
            this.groupBox6.Controls.Add(this.label99);
            this.groupBox6.Controls.Add(this.radioButton3);
            this.groupBox6.Controls.Add(this.radioButton5);
            this.groupBox6.Location = new System.Drawing.Point(96, 383);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(203, 37);
            this.groupBox6.TabIndex = 198;
            this.groupBox6.TabStop = false;
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Location = new System.Drawing.Point(11, 51);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(81, 13);
            this.label97.TabIndex = 4;
            this.label97.Text = "Temporary Pole";
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Location = new System.Drawing.Point(100, 18);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(61, 13);
            this.label98.TabIndex = 3;
            this.label98.Text = "Commercial";
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Location = new System.Drawing.Point(5, 18);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(59, 13);
            this.label99.TabIndex = 2;
            this.label99.Text = "Residential";
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(167, 18);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(14, 13);
            this.radioButton3.TabIndex = 1;
            this.radioButton3.TabStop = true;
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Location = new System.Drawing.Point(70, 17);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(14, 13);
            this.radioButton5.TabIndex = 0;
            this.radioButton5.TabStop = true;
            this.radioButton5.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.label100);
            this.groupBox7.Controls.Add(this.radioButton7);
            this.groupBox7.Location = new System.Drawing.Point(95, 419);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(122, 37);
            this.groupBox7.TabIndex = 197;
            this.groupBox7.TabStop = false;
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Location = new System.Drawing.Point(6, 13);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(81, 13);
            this.label100.TabIndex = 1;
            this.label100.Text = "Temporary Pole";
            // 
            // radioButton7
            // 
            this.radioButton7.AutoSize = true;
            this.radioButton7.Location = new System.Drawing.Point(94, 14);
            this.radioButton7.Name = "radioButton7";
            this.radioButton7.Size = new System.Drawing.Size(14, 13);
            this.radioButton7.TabIndex = 0;
            this.radioButton7.TabStop = true;
            this.radioButton7.UseVisualStyleBackColor = true;
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.Location = new System.Drawing.Point(332, 391);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(109, 13);
            this.label101.TabIndex = 195;
            this.label101.Text = "Total # of Bathrooms:";
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label102.Location = new System.Drawing.Point(36, 391);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(58, 13);
            this.label102.TabIndex = 194;
            this.label102.Text = "Plumbing";
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.Location = new System.Drawing.Point(35, 372);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(595, 13);
            this.label103.TabIndex = 193;
            this.label103.Text = "---------------------------------------------------------------------------------" +
                "--------------------------------------------------------------------------------" +
                "-----------------------------------";
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.Location = new System.Drawing.Point(332, 277);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(109, 13);
            this.label104.TabIndex = 190;
            this.label104.Text = "Total # of Bathrooms:";
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.Location = new System.Drawing.Point(114, 277);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(95, 13);
            this.label105.TabIndex = 189;
            this.label105.Text = "Total # of Fixtures:";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.label106);
            this.groupBox8.Controls.Add(this.radioButton11);
            this.groupBox8.Location = new System.Drawing.Point(44, 339);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(136, 37);
            this.groupBox8.TabIndex = 188;
            this.groupBox8.TabStop = false;
            // 
            // label106
            // 
            this.label106.AutoSize = true;
            this.label106.Location = new System.Drawing.Point(13, 16);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(84, 13);
            this.label106.TabIndex = 2;
            this.label106.Text = "Irrigation System";
            // 
            // radioButton11
            // 
            this.radioButton11.AutoSize = true;
            this.radioButton11.Location = new System.Drawing.Point(111, 15);
            this.radioButton11.Name = "radioButton11";
            this.radioButton11.Size = new System.Drawing.Size(14, 13);
            this.radioButton11.TabIndex = 0;
            this.radioButton11.TabStop = true;
            this.radioButton11.UseVisualStyleBackColor = true;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.label107);
            this.groupBox9.Controls.Add(this.radioButton12);
            this.groupBox9.Location = new System.Drawing.Point(44, 214);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(101, 37);
            this.groupBox9.TabIndex = 185;
            this.groupBox9.TabStop = false;
            // 
            // label107
            // 
            this.label107.AutoSize = true;
            this.label107.Location = new System.Drawing.Point(13, 14);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(52, 13);
            this.label107.TabIndex = 1;
            this.label107.Text = "Gas Line:";
            // 
            // radioButton12
            // 
            this.radioButton12.AutoSize = true;
            this.radioButton12.Location = new System.Drawing.Point(76, 14);
            this.radioButton12.Name = "radioButton12";
            this.radioButton12.Size = new System.Drawing.Size(14, 13);
            this.radioButton12.TabIndex = 0;
            this.radioButton12.TabStop = true;
            this.radioButton12.UseVisualStyleBackColor = true;
            // 
            // label108
            // 
            this.label108.AutoSize = true;
            this.label108.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label108.Location = new System.Drawing.Point(36, 277);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(58, 13);
            this.label108.TabIndex = 187;
            this.label108.Text = "Plumbing";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.radioButton13);
            this.groupBox10.Controls.Add(this.radioButton14);
            this.groupBox10.Location = new System.Drawing.Point(142, 158);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(206, 25);
            this.groupBox10.TabIndex = 184;
            this.groupBox10.TabStop = false;
            // 
            // radioButton13
            // 
            this.radioButton13.AutoSize = true;
            this.radioButton13.Location = new System.Drawing.Point(108, 7);
            this.radioButton13.Name = "radioButton13";
            this.radioButton13.Size = new System.Drawing.Size(79, 17);
            this.radioButton13.TabIndex = 1;
            this.radioButton13.TabStop = true;
            this.radioButton13.Text = "Commercial";
            this.radioButton13.UseVisualStyleBackColor = true;
            // 
            // radioButton14
            // 
            this.radioButton14.AutoSize = true;
            this.radioButton14.Location = new System.Drawing.Point(18, 7);
            this.radioButton14.Name = "radioButton14";
            this.radioButton14.Size = new System.Drawing.Size(77, 17);
            this.radioButton14.TabIndex = 0;
            this.radioButton14.TabStop = true;
            this.radioButton14.Text = "Residential";
            this.radioButton14.UseVisualStyleBackColor = true;
            // 
            // label109
            // 
            this.label109.AutoSize = true;
            this.label109.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label109.Location = new System.Drawing.Point(32, 164);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(72, 13);
            this.label109.TabIndex = 183;
            this.label109.Text = "Mechanical";
            // 
            // label110
            // 
            this.label110.AutoSize = true;
            this.label110.Location = new System.Drawing.Point(267, 192);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(98, 13);
            this.label110.TabIndex = 180;
            this.label110.Text = "Number of Systems";
            // 
            // label111
            // 
            this.label111.AutoSize = true;
            this.label111.Location = new System.Drawing.Point(35, 255);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(595, 13);
            this.label111.TabIndex = 186;
            this.label111.Text = "---------------------------------------------------------------------------------" +
                "--------------------------------------------------------------------------------" +
                "-----------------------------------";
            // 
            // label112
            // 
            this.label112.AutoSize = true;
            this.label112.Location = new System.Drawing.Point(41, 192);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(83, 13);
            this.label112.TabIndex = 179;
            this.label112.Text = "Type of System:";
            // 
            // label113
            // 
            this.label113.AutoSize = true;
            this.label113.Location = new System.Drawing.Point(31, 142);
            this.label113.Name = "label113";
            this.label113.Size = new System.Drawing.Size(595, 13);
            this.label113.TabIndex = 178;
            this.label113.Text = "---------------------------------------------------------------------------------" +
                "--------------------------------------------------------------------------------" +
                "-----------------------------------";
            // 
            // textBox84
            // 
            this.textBox84.Location = new System.Drawing.Point(622, 97);
            this.textBox84.Name = "textBox84";
            this.textBox84.Size = new System.Drawing.Size(60, 20);
            this.textBox84.TabIndex = 194;
            // 
            // textBox85
            // 
            this.textBox85.Location = new System.Drawing.Point(473, 97);
            this.textBox85.Name = "textBox85";
            this.textBox85.Size = new System.Drawing.Size(100, 20);
            this.textBox85.TabIndex = 193;
            // 
            // textBox86
            // 
            this.textBox86.Location = new System.Drawing.Point(338, 132);
            this.textBox86.Name = "textBox86";
            this.textBox86.Size = new System.Drawing.Size(100, 20);
            this.textBox86.TabIndex = 192;
            // 
            // textBox87
            // 
            this.textBox87.Location = new System.Drawing.Point(303, 97);
            this.textBox87.Name = "textBox87";
            this.textBox87.Size = new System.Drawing.Size(100, 20);
            this.textBox87.TabIndex = 197;
            // 
            // textBox88
            // 
            this.textBox88.Location = new System.Drawing.Point(115, 97);
            this.textBox88.Name = "textBox88";
            this.textBox88.Size = new System.Drawing.Size(100, 20);
            this.textBox88.TabIndex = 196;
            // 
            // textBox89
            // 
            this.textBox89.Location = new System.Drawing.Point(552, 60);
            this.textBox89.Name = "textBox89";
            this.textBox89.Size = new System.Drawing.Size(100, 20);
            this.textBox89.TabIndex = 195;
            // 
            // textBox90
            // 
            this.textBox90.Location = new System.Drawing.Point(336, 60);
            this.textBox90.Name = "textBox90";
            this.textBox90.Size = new System.Drawing.Size(100, 20);
            this.textBox90.TabIndex = 191;
            // 
            // textBox91
            // 
            this.textBox91.Location = new System.Drawing.Point(116, 60);
            this.textBox91.Name = "textBox91";
            this.textBox91.Size = new System.Drawing.Size(100, 20);
            this.textBox91.TabIndex = 190;
            // 
            // textBox92
            // 
            this.textBox92.Location = new System.Drawing.Point(442, 28);
            this.textBox92.Name = "textBox92";
            this.textBox92.Size = new System.Drawing.Size(100, 20);
            this.textBox92.TabIndex = 189;
            // 
            // textBox93
            // 
            this.textBox93.Location = new System.Drawing.Point(211, 28);
            this.textBox93.Name = "textBox93";
            this.textBox93.Size = new System.Drawing.Size(100, 20);
            this.textBox93.TabIndex = 188;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(42, 134);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(101, 17);
            this.checkBox1.TabIndex = 199;
            this.checkBox1.Text = "Install Insulation";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // label114
            // 
            this.label114.AutoSize = true;
            this.label114.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label114.Location = new System.Drawing.Point(28, 31);
            this.label114.Name = "label114";
            this.label114.Size = new System.Drawing.Size(52, 13);
            this.label114.TabIndex = 198;
            this.label114.Text = "Building";
            // 
            // label115
            // 
            this.label115.AutoSize = true;
            this.label115.Location = new System.Drawing.Point(583, 101);
            this.label115.Name = "label115";
            this.label115.Size = new System.Drawing.Size(33, 13);
            this.label115.TabIndex = 186;
            this.label115.Text = "Deck";
            // 
            // label116
            // 
            this.label116.AutoSize = true;
            this.label116.Location = new System.Drawing.Point(416, 100);
            this.label116.Name = "label116";
            this.label116.Size = new System.Drawing.Size(51, 13);
            this.label116.TabIndex = 180;
            this.label116.Text = "Porch SF";
            // 
            // label117
            // 
            this.label117.AutoSize = true;
            this.label117.Location = new System.Drawing.Point(181, 134);
            this.label117.Name = "label117";
            this.label117.Size = new System.Drawing.Size(151, 13);
            this.label117.TabIndex = 179;
            this.label117.Text = "Estimated Cost of Construction";
            // 
            // label118
            // 
            this.label118.AutoSize = true;
            this.label118.Location = new System.Drawing.Point(243, 100);
            this.label118.Name = "label118";
            this.label118.Size = new System.Drawing.Size(54, 13);
            this.label118.TabIndex = 183;
            this.label118.Text = "Basement";
            // 
            // label119
            // 
            this.label119.AutoSize = true;
            this.label119.Location = new System.Drawing.Point(28, 97);
            this.label119.Name = "label119";
            this.label119.Size = new System.Drawing.Size(58, 13);
            this.label119.TabIndex = 182;
            this.label119.Text = "Garage SF";
            // 
            // label120
            // 
            this.label120.AutoSize = true;
            this.label120.Location = new System.Drawing.Point(465, 60);
            this.label120.Name = "label120";
            this.label120.Size = new System.Drawing.Size(61, 13);
            this.label120.TabIndex = 181;
            this.label120.Text = "# of Stories";
            // 
            // label121
            // 
            this.label121.AutoSize = true;
            this.label121.Location = new System.Drawing.Point(249, 60);
            this.label121.Name = "label121";
            this.label121.Size = new System.Drawing.Size(58, 13);
            this.label121.TabIndex = 178;
            this.label121.Text = "Heated SF";
            // 
            // label122
            // 
            this.label122.AutoSize = true;
            this.label122.Location = new System.Drawing.Point(29, 60);
            this.label122.Name = "label122";
            this.label122.Size = new System.Drawing.Size(61, 13);
            this.label122.TabIndex = 187;
            this.label122.Text = "Dimensions";
            // 
            // label123
            // 
            this.label123.AutoSize = true;
            this.label123.Location = new System.Drawing.Point(355, 32);
            this.label123.Name = "label123";
            this.label123.Size = new System.Drawing.Size(74, 13);
            this.label123.TabIndex = 185;
            this.label123.Text = "Proposed Use";
            // 
            // label124
            // 
            this.label124.AutoSize = true;
            this.label124.Location = new System.Drawing.Point(99, 32);
            this.label124.Name = "label124";
            this.label124.Size = new System.Drawing.Size(105, 13);
            this.label124.TabIndex = 184;
            this.label124.Text = "Type of Construction";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(119, 160);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(112, 20);
            this.textBox2.TabIndex = 174;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(119, 131);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(110, 20);
            this.textBox8.TabIndex = 175;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(42, 163);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(70, 13);
            this.label19.TabIndex = 172;
            this.label19.Text = "Deposit Amnt";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(40, 134);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(57, 13);
            this.label20.TabIndex = 173;
            this.label20.Text = "Total Fees";
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(323, 160);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(110, 20);
            this.textBox9.TabIndex = 178;
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(323, 131);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(108, 20);
            this.textBox22.TabIndex = 179;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(251, 163);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(66, 13);
            this.label21.TabIndex = 176;
            this.label21.Text = "Amount Due";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(247, 134);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(67, 13);
            this.label22.TabIndex = 177;
            this.label22.Text = "Amount Paid";
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Location = new System.Drawing.Point(43, 73);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(93, 13);
            this.label83.TabIndex = 187;
            this.label83.Text = "Construction Type";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(155, 70);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(177, 21);
            this.comboBox2.TabIndex = 186;
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(43, 46);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(63, 13);
            this.label82.TabIndex = 185;
            this.label82.Text = "Permit Type";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(155, 43);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(177, 21);
            this.comboBox1.TabIndex = 184;
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(596, 34);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(100, 20);
            this.textBox23.TabIndex = 189;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(541, 37);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(46, 13);
            this.label23.TabIndex = 188;
            this.label23.Text = "Permit #";
            // 
            // dateTimePicker3
            // 
            this.dateTimePicker3.Location = new System.Drawing.Point(596, 142);
            this.dateTimePicker3.Name = "dateTimePicker3";
            this.dateTimePicker3.Size = new System.Drawing.Size(100, 20);
            this.dateTimePicker3.TabIndex = 191;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(531, 144);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(58, 13);
            this.label24.TabIndex = 190;
            this.label24.Text = "Issue Date";
            // 
            // BuildingPermitTabs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(726, 505);
            this.Controls.Add(this.tabControl1);
            this.Name = "BuildingPermitTabs";
            this.Text = "BuildingPermitTabs";
            this.Load += new System.EventHandler(this.BuildingPermitTabs_Load);
            this.Contractor.ResumeLayout(false);
            this.Contractor.PerformLayout();
            this.Contractors.ResumeLayout(false);
            this.Contractors.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabPage Contractor;
        private System.Windows.Forms.TabPage Contractors;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        internal System.Windows.Forms.Label label87;
        internal System.Windows.Forms.Label label86;
        internal System.Windows.Forms.Label label85;
        private System.Windows.Forms.ComboBox comboBox3;
        internal System.Windows.Forms.TextBox textBox69;
        internal System.Windows.Forms.TextBox textBox12;
        internal System.Windows.Forms.TextBox textBox13;
        internal System.Windows.Forms.TextBox textBox14;
        internal System.Windows.Forms.TextBox textBox15;
        internal System.Windows.Forms.TextBox textBox16;
        internal System.Windows.Forms.TextBox textBox17;
        internal System.Windows.Forms.TextBox textBox18;
        internal System.Windows.Forms.TextBox textBox19;
        internal System.Windows.Forms.TextBox textBox20;
        internal System.Windows.Forms.TextBox textBox21;
        internal System.Windows.Forms.TextBox TextBox7;
        internal System.Windows.Forms.TextBox TextBox6;
        internal System.Windows.Forms.TextBox TextBox5;
        internal System.Windows.Forms.TextBox TextBox4;
        internal System.Windows.Forms.TextBox TextBox3;
        internal System.Windows.Forms.TextBox textBox11;
        internal System.Windows.Forms.TextBox textBox10;
        internal System.Windows.Forms.TextBox TextBox1;
        internal System.Windows.Forms.Label label84;
        private System.Windows.Forms.Button button1;
        internal System.Windows.Forms.Label label9;
        private System.Windows.Forms.MaskedTextBox maskedTextBox2;
        private System.Windows.Forms.MaskedTextBox maskedTextBox1;
        internal System.Windows.Forms.Label label11;
        internal System.Windows.Forms.Label label12;
        internal System.Windows.Forms.Label label13;
        internal System.Windows.Forms.Label label14;
        internal System.Windows.Forms.Label label15;
        internal System.Windows.Forms.Label label16;
        internal System.Windows.Forms.Label label17;
        internal System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label10;
        internal System.Windows.Forms.Label Label8;
        internal System.Windows.Forms.Label Label7;
        internal System.Windows.Forms.Label Label6;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.Label Title;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        internal System.Windows.Forms.TextBox textBox66;
        internal System.Windows.Forms.TextBox textBox67;
        internal System.Windows.Forms.TextBox textBox68;
        internal System.Windows.Forms.TextBox textBox63;
        internal System.Windows.Forms.TextBox textBox64;
        internal System.Windows.Forms.TextBox textBox65;
        internal System.Windows.Forms.TextBox textBox60;
        internal System.Windows.Forms.TextBox textBox61;
        internal System.Windows.Forms.TextBox textBox62;
        internal System.Windows.Forms.TextBox textBox57;
        internal System.Windows.Forms.TextBox textBox58;
        internal System.Windows.Forms.TextBox textBox59;
        internal System.Windows.Forms.TextBox textBox56;
        internal System.Windows.Forms.TextBox textBox54;
        internal System.Windows.Forms.TextBox textBox55;
        internal System.Windows.Forms.TextBox textBox53;
        internal System.Windows.Forms.TextBox textBox43;
        internal System.Windows.Forms.TextBox textBox44;
        internal System.Windows.Forms.TextBox textBox45;
        internal System.Windows.Forms.TextBox textBox46;
        internal System.Windows.Forms.TextBox textBox47;
        internal System.Windows.Forms.TextBox textBox48;
        internal System.Windows.Forms.TextBox textBox49;
        internal System.Windows.Forms.TextBox textBox50;
        internal System.Windows.Forms.TextBox textBox51;
        internal System.Windows.Forms.TextBox textBox52;
        internal System.Windows.Forms.Label label79;
        internal System.Windows.Forms.Label label80;
        internal System.Windows.Forms.Label label81;
        internal System.Windows.Forms.Label label76;
        internal System.Windows.Forms.Label label77;
        internal System.Windows.Forms.Label label78;
        internal System.Windows.Forms.Label label73;
        internal System.Windows.Forms.Label label74;
        internal System.Windows.Forms.Label label75;
        internal System.Windows.Forms.Label label70;
        internal System.Windows.Forms.Label label71;
        internal System.Windows.Forms.Label label72;
        internal System.Windows.Forms.Label label69;
        internal System.Windows.Forms.Label label67;
        internal System.Windows.Forms.Label label68;
        internal System.Windows.Forms.Label label56;
        private System.Windows.Forms.CheckBox checkBox10;
        internal System.Windows.Forms.Label label57;
        internal System.Windows.Forms.Label label58;
        internal System.Windows.Forms.Label label59;
        internal System.Windows.Forms.Label label60;
        internal System.Windows.Forms.Label label61;
        internal System.Windows.Forms.Label label62;
        internal System.Windows.Forms.Label label63;
        internal System.Windows.Forms.Label label64;
        internal System.Windows.Forms.Label label65;
        internal System.Windows.Forms.Label label66;
        private System.Windows.Forms.Button button5;
        internal System.Windows.Forms.TextBox textBox70;
        internal System.Windows.Forms.TextBox textBox71;
        internal System.Windows.Forms.TextBox textBox72;
        internal System.Windows.Forms.TextBox textBox73;
        internal System.Windows.Forms.TextBox textBox74;
        internal System.Windows.Forms.TextBox textBox75;
        internal System.Windows.Forms.TextBox textBox76;
        internal System.Windows.Forms.TextBox textBox77;
        internal System.Windows.Forms.TextBox textBox78;
        internal System.Windows.Forms.TextBox textBox79;
        internal System.Windows.Forms.TextBox textBox80;
        internal System.Windows.Forms.TextBox textBox81;
        internal System.Windows.Forms.TextBox textBox82;
        internal System.Windows.Forms.TextBox textBox83;
        internal System.Windows.Forms.Label label88;
        internal System.Windows.Forms.Label label89;
        internal System.Windows.Forms.Label label90;
        internal System.Windows.Forms.Label label91;
        internal System.Windows.Forms.Label label92;
        internal System.Windows.Forms.Label label93;
        internal System.Windows.Forms.Label label94;
        internal System.Windows.Forms.Label label95;
        internal System.Windows.Forms.Label label96;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.RadioButton radioButton7;
        internal System.Windows.Forms.Label label101;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.Label label103;
        internal System.Windows.Forms.Label label104;
        internal System.Windows.Forms.Label label105;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.RadioButton radioButton11;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.RadioButton radioButton12;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.RadioButton radioButton13;
        private System.Windows.Forms.RadioButton radioButton14;
        private System.Windows.Forms.Label label109;
        internal System.Windows.Forms.Label label110;
        private System.Windows.Forms.Label label111;
        internal System.Windows.Forms.Label label112;
        private System.Windows.Forms.Label label113;
        internal System.Windows.Forms.TextBox textBox84;
        internal System.Windows.Forms.TextBox textBox85;
        internal System.Windows.Forms.TextBox textBox86;
        internal System.Windows.Forms.TextBox textBox87;
        internal System.Windows.Forms.TextBox textBox88;
        internal System.Windows.Forms.TextBox textBox89;
        internal System.Windows.Forms.TextBox textBox90;
        internal System.Windows.Forms.TextBox textBox91;
        internal System.Windows.Forms.TextBox textBox92;
        internal System.Windows.Forms.TextBox textBox93;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label label114;
        internal System.Windows.Forms.Label label115;
        internal System.Windows.Forms.Label label116;
        internal System.Windows.Forms.Label label117;
        internal System.Windows.Forms.Label label118;
        internal System.Windows.Forms.Label label119;
        internal System.Windows.Forms.Label label120;
        internal System.Windows.Forms.Label label121;
        internal System.Windows.Forms.Label label122;
        internal System.Windows.Forms.Label label123;
        internal System.Windows.Forms.Label label124;
        private System.Windows.Forms.DateTimePicker dateTimePicker3;
        internal System.Windows.Forms.Label label24;
        internal System.Windows.Forms.TextBox textBox23;
        internal System.Windows.Forms.Label label23;
        internal System.Windows.Forms.Label label83;
        private System.Windows.Forms.ComboBox comboBox2;
        internal System.Windows.Forms.Label label82;
        private System.Windows.Forms.ComboBox comboBox1;
        internal System.Windows.Forms.TextBox textBox9;
        internal System.Windows.Forms.TextBox textBox22;
        internal System.Windows.Forms.Label label21;
        internal System.Windows.Forms.Label label22;
        internal System.Windows.Forms.TextBox textBox2;
        internal System.Windows.Forms.TextBox textBox8;
        internal System.Windows.Forms.Label label19;
        internal System.Windows.Forms.Label label20;


    }
}